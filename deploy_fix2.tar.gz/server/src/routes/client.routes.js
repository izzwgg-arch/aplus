import express from "express";
import multer from "multer";
import { prisma } from "../config/prisma.js";
import { requireAuth } from "../middleware/auth.js";
import { upload } from "../middleware/upload.js";
import { encryptText, decryptText } from "../utils/crypto.js";
import { getOrCreateClinicSettings } from "../services/settingsService.js";
import { writeAuditLog } from "../services/auditLogService.js";
import { syncClientToQuickbooks } from "../services/integrations/quickbooks/quickbooksService.js";
import { ensureClientDefaultFolders } from "../services/documentRootsService.js";

const router = express.Router();
router.use(requireAuth);

const csvUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 }
});

function csvEscape(value) {
  const str = value == null ? "" : String(value);
  if (!/[",\n\r]/.test(str)) return str;
  return `"${str.replace(/"/g, "\"\"")}"`;
}

function splitCsvLine(line) {
  const out = [];
  let current = "";
  let inQuotes = false;
  for (let i = 0; i < line.length; i += 1) {
    const char = line[i];
    const next = line[i + 1];
    if (char === "\"") {
      if (inQuotes && next === "\"") {
        current += "\"";
        i += 1;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (char === "," && !inQuotes) {
      out.push(current);
      current = "";
    } else {
      current += char;
    }
  }
  out.push(current);
  return out.map((entry) => entry.trim());
}

function normalizeHeader(header) {
  return String(header || "").trim().toLowerCase().replace(/[^a-z0-9]/g, "");
}

function toCanonicalHeader(header) {
  const key = normalizeHeader(header);
  const map = {
    firstname: "firstName",
    lastname: "lastName",
    fullname: "fullName",
    clientname: "fullName",
    name: "fullName",
    dob: "dob",
    dateofbirth: "dob",
    birthdate: "dob",
    phone: "phone",
    phone1: "phoneAlt1",
    phone2: "phoneAlt2",
    phonenumber: "phone",
    email: "email",
    email1: "emailAlt1",
    email2: "emailAlt2",
    emailaddress: "email",
    zip: "zip",
    zipcode: "zip",
    postalcode: "zip",
    insurance: "insurance",
    insuranceprovider: "insurance",
    address: "address",
    streetaddress: "address",
    notes: "notes",
    note: "notes",
    hourlyrate: "hourlyRate",
    rate: "hourlyRate",
    status: "status",
    cancellationfeeenabled: "cancellationFeeEnabled",
    cancellationfee: "cancellationFeeEnabled",
    cancelationfeeenabled: "cancellationFeeEnabled"
  };
  return map[key] || null;
}

router.get("/export.csv", async (req, res) => {
  const clients = await prisma.client.findMany({ orderBy: { createdAt: "desc" } });
  const rows = [
    ["firstName", "lastName", "fullName", "dob", "phone", "email", "zip", "insurance", "address", "notes", "hourlyRate", "status", "cancellationFeeEnabled"]
  ];
  for (const client of clients) {
    rows.push([
      client.firstName || "",
      client.lastName || "",
      client.fullName || "",
      client.dob ? client.dob.toISOString().slice(0, 10) : "",
      client.phone || "",
      client.email || "",
      client.zip || "",
      client.insurance || "",
      decryptText(client.addressEncrypted) || "",
      decryptText(client.notesEncrypted) || "",
      client.hourlyRate ?? "",
      client.status || "ACTIVE",
      client.cancellationFeeEnabled ? "true" : "false"
    ]);
  }
  const csvText = rows.map((row) => row.map(csvEscape).join(",")).join("\n");
  await writeAuditLog(req, {
    action: "CLIENTS_CSV_EXPORTED",
    entityType: "Client",
    detailsJson: { count: clients.length }
  });
  res.setHeader("Content-Type", "text/csv; charset=utf-8");
  res.setHeader("Content-Disposition", "attachment; filename=\"clients-export.csv\"");
  return res.status(200).send(csvText);
});

router.post("/import.csv", csvUpload.single("file"), async (req, res) => {
  if (!req.file?.buffer) return res.status(400).json({ error: "CSV file is required" });
  const raw = req.file.buffer.toString("utf8").replace(/^\uFEFF/, "");
  const lines = raw.split(/\r?\n/).filter((line) => line.trim().length > 0);
  if (lines.length < 2) return res.status(400).json({ error: "CSV must include headers and at least one row" });

  const headers = splitCsvLine(lines[0]);
  const headerIndex = {};
  headers.forEach((header, idx) => {
    const canonical = toCanonicalHeader(header);
    if (canonical && headerIndex[canonical] === undefined) headerIndex[canonical] = idx;
  });
  const requiredAnyName = ["fullName", "firstName", "lastName"].some((key) => headerIndex[key] !== undefined);
  if (!requiredAnyName) {
    return res.status(400).json({
      error: "CSV requires at least one name header. Accepted examples: fullName/name OR firstName/lastName."
    });
  }
  const hasDobColumn = headerIndex.dob !== undefined;

  const settings = await getOrCreateClinicSettings();
  let imported = 0;
  let defaultDobApplied = 0;
  const errors = [];

  for (let i = 1; i < lines.length; i += 1) {
    const row = splitCsvLine(lines[i]);
    const get = (field) => {
      const idx = headerIndex[field];
      return idx === undefined ? "" : (row[idx] || "").trim();
    };
    try {
      const firstName = get("firstName") || null;
      const lastName = get("lastName") || null;
      const fullName = get("fullName") || [firstName, lastName].filter(Boolean).join(" ");
      if (!fullName) throw new Error("Missing name");
      const phone = get("phone") || get("phoneAlt1") || get("phoneAlt2") || "";
      const email = get("email") || get("emailAlt1") || get("emailAlt2") || "";
      const zip = get("zip") || "";
      const dob = hasDobColumn ? get("dob") : "";
      let parsedDob;
      if (dob) {
        parsedDob = new Date(dob);
        if (Number.isNaN(parsedDob.getTime())) {
          parsedDob = new Date("2000-01-01T00:00:00.000Z");
          defaultDobApplied += 1;
        }
      } else {
        parsedDob = new Date("2000-01-01T00:00:00.000Z");
        defaultDobApplied += 1;
      }
      const statusRaw = get("status").toUpperCase();
      const status = ["ACTIVE", "INACTIVE", "WAITLIST"].includes(statusRaw) ? statusRaw : "ACTIVE";
      const feeRaw = get("cancellationFeeEnabled").toLowerCase();
      const cancellationFeeEnabled = feeRaw === "true" || feeRaw === "1"
        ? true
        : feeRaw === "false" || feeRaw === "0"
          ? false
          : settings.defaultCancellationFeeEnabled;
      const hourlyRateRaw = get("hourlyRate");

      await prisma.client.create({
        data: {
          firstName,
          lastName,
          fullName,
          dob: parsedDob,
          phone,
          email,
          zip,
          insurance: get("insurance") || null,
          addressEncrypted: encryptText(get("address") || ""),
          notesEncrypted: encryptText(get("notes") || ""),
          hourlyRate: hourlyRateRaw ? Number(hourlyRateRaw) : null,
          status,
          cancellationFeeEnabled
        }
      });
      imported += 1;
    } catch (error) {
      errors.push({ row: i + 1, error: error.message || "Invalid row" });
    }
  }

  await writeAuditLog(req, {
    action: "CLIENTS_CSV_IMPORTED",
    entityType: "Client",
    detailsJson: { imported, failed: errors.length, defaultDobApplied }
  });
  return res.json({
    imported,
    failed: errors.length,
    defaultDobApplied,
    errors: errors.slice(0, 25)
  });
});

router.get("/", async (req, res) => {
  // ── Paginated lean mode (Clients directory) ──────────────────────────────
  // Activated when caller passes ?page= or ?limit=
  // Returns: { data, total, page, limit, totalPages }
  if (req.query.page !== undefined || req.query.limit !== undefined) {
    const page   = Math.max(1, Number(req.query.page  || 1));
    const limit  = Math.min(200, Math.max(1, Number(req.query.limit || 50)));
    const search = (req.query.search || "").trim();
    const skip   = (page - 1) * limit;

    const where = {};
    if (search) {
      where.OR = [
        { fullName:  { contains: search, mode: "insensitive" } },
        { phone:     { contains: search, mode: "insensitive" } },
        { insurance: { contains: search, mode: "insensitive" } },
        { email:     { contains: search, mode: "insensitive" } },
      ];
    }
    if (req.query.defaultDobOnly === "true") {
      where.dob = new Date("2000-01-01T00:00:00.000Z");
    }

    const [total, clients] = await prisma.$transaction([
      prisma.client.count({ where }),
      prisma.client.findMany({
        where,
        orderBy: { fullName: "asc" },
        skip,
        take: limit,
        select: {
          id: true,
          firstName: true,
          lastName: true,
          fullName: true,
          dob: true,
          phone: true,
          insurance: true,
          status: true,
        }
      })
    ]);

    return res.json({
      data: clients,
      total,
      page,
      limit,
      totalPages: Math.max(1, Math.ceil(total / limit))
    });
  }

  // ── Legacy full-list mode (dropdowns in appointment/other pages) ─────────
  // Returns a flat array — no pagination — with decrypted fields
  const clients = await prisma.client.findMany({ orderBy: { fullName: "asc" } });
  return res.json(
    clients
      .map((c) => ({ ...c, address: decryptText(c.addressEncrypted), notes: decryptText(c.notesEncrypted) }))
      .sort((a, b) => (a.fullName ?? "").trim().toLowerCase().localeCompare((b.fullName ?? "").trim().toLowerCase()))
  );
});

router.post("/", async (req, res) => {
  const data = req.body;
  const settings = await getOrCreateClinicSettings();
  const firstName = data.firstName ? String(data.firstName).trim() : null;
  const lastName = data.lastName ? String(data.lastName).trim() : null;
  const fullName = data.fullName || [firstName, lastName].filter(Boolean).join(" ");
  if (!fullName) return res.status(400).json({ error: "Client full name is required" });
  const created = await prisma.client.create({
    data: {
      firstName,
      lastName,
      fullName,
      // DOB is optional — guard against null/empty/undefined so Prisma never receives Invalid Date
      dob: data.dob ? new Date(data.dob) : null,
      phone: data.phone,
      email: data.email,
      zip: data.zip,
      insurance: data.insurance || null,
      addressEncrypted: encryptText(data.address),
      notesEncrypted: encryptText(data.notes || ""),
      hourlyRate: data.hourlyRate ? Number(data.hourlyRate) : null,
      profileImageUrl: data.profileImageUrl || null,
      status: data.status || "ACTIVE",
      cancellationFeeEnabled: typeof data.cancellationFeeEnabled === "boolean"
        ? data.cancellationFeeEnabled
        : settings.defaultCancellationFeeEnabled
    }
  });
  // Auto-create all required document workspace roots for the new client
  await ensureClientDefaultFolders(created.id);

  await writeAuditLog(req, {
    action: "CLIENT_CREATED",
    entityType: "Client",
    entityId: created.id
  });
  return res.status(201).json(created);
});

router.put("/:id", async (req, res) => {
  const data = req.body;
  const updated = await prisma.client.update({
    where: { id: req.params.id },
    data: {
      firstName: data.firstName !== undefined ? String(data.firstName).trim() : undefined,
      lastName:  data.lastName  !== undefined ? String(data.lastName).trim()  : undefined,
      fullName:  data.fullName  || undefined,
      // Allow explicitly clearing DOB (send null) or leaving unchanged (undefined)
      dob: data.dob !== undefined ? (data.dob ? new Date(data.dob) : null) : undefined,
      phone: data.phone,
      email: data.email,
      zip:   data.zip,
      insurance: data.insurance || null,
      // Always update encrypted fields when present (allows clearing them)
      addressEncrypted: data.address !== undefined ? encryptText(data.address ?? "") : undefined,
      notesEncrypted:   data.notes   !== undefined ? encryptText(data.notes   ?? "") : undefined,
      hourlyRate: data.hourlyRate ? Number(data.hourlyRate) : null,
      profileImageUrl: data.profileImageUrl || undefined,
      status: data.status || undefined,
      cancellationFeeEnabled: typeof data.cancellationFeeEnabled === "boolean" ? data.cancellationFeeEnabled : undefined
    }
  });
  await writeAuditLog(req, {
    action: "CLIENT_UPDATED",
    entityType: "Client",
    entityId: updated.id
  });
  return res.json(updated);
});

router.get("/:id", async (req, res) => {
  const client = await prisma.client.findUnique({
    where: { id: req.params.id },
    include: {
      appointments: { orderBy: { startsAt: "desc" } },
      invoices: { include: { payments: true, lineItems: true }, orderBy: { createdAt: "desc" } },
      payments: { include: { refunds: true }, orderBy: { paymentDate: "desc" } },
      paymentMethodSnapshots: { orderBy: { createdAt: "desc" } },
      assessments: { orderBy: { createdAt: "desc" } },
      dataTrackingEntries: { orderBy: { createdAt: "desc" } },
      documents: { orderBy: { uploadedAt: "desc" } }
    }
  });
  if (!client) return res.status(404).json({ error: "Client not found" });
  return res.json({
    ...client,
    address: decryptText(client.addressEncrypted),
    notes: decryptText(client.notesEncrypted)
  });
});

router.patch("/:id/status", async (req, res) => {
  const status = req.body?.status;
  if (!["ACTIVE", "INACTIVE", "WAITLIST"].includes(status)) {
    return res.status(400).json({ error: "Invalid client status" });
  }
  const updated = await prisma.client.update({
    where: { id: req.params.id },
    data: { status }
  });
  await writeAuditLog(req, {
    action: "CLIENT_STATUS_UPDATED",
    entityType: "Client",
    entityId: updated.id,
    detailsJson: { status }
  });
  return res.json(updated);
});

router.post("/:id/profile-image", upload.single("image"), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: "Missing image file" });
  const updated = await prisma.client.update({
    where: { id: req.params.id },
    data: { profileImageUrl: req.file.path }
  });
  await writeAuditLog(req, {
    action: "CLIENT_PROFILE_IMAGE_UPDATED",
    entityType: "Client",
    entityId: updated.id
  });
  return res.json(updated);
});

router.post("/:id/documents", upload.single("file"), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: "Missing file" });
  const doc = await prisma.document.create({
    data: {
      clientId: req.params.id,
      fileName: req.file.originalname,
      filePath: req.file.path,
      mimeType: req.file.mimetype
    }
  });
  await writeAuditLog(req, {
    action: "CLIENT_DOCUMENT_UPLOADED",
    entityType: "Client",
    entityId: req.params.id,
    detailsJson: { documentId: doc.id, fileName: doc.fileName }
  });
  return res.status(201).json(doc);
});

router.post("/:id/sync/quickbooks", async (req, res) => {
  try {
    const result = await syncClientToQuickbooks(req.params.id);
    await writeAuditLog(req, {
      action: "QUICKBOOKS_CLIENT_SYNC_TRIGGERED",
      entityType: "Client",
      entityId: req.params.id
    });
    return res.json(result);
  } catch (error) {
    return res.status(error.status || 500).json({ error: error.message || "Client sync failed" });
  }
});

export default router;
