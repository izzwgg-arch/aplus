import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { prisma } from "@/lib/db";

export async function POST(
  _req: Request,
  { params }: { params: Promise<{ itemId: string }> },
) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const role = (session.user as { role?: string }).role;
  if (role !== "ADMIN" && role !== "BCBA") {
    return NextResponse.json({ error: "Forbidden: only ADMIN or BCBA can clone templates" }, { status: 403 });
  }

  const { itemId } = await params;

  try {
    const source = await prisma.parentGoalLibraryItem.findUnique({ where: { id: itemId } });
    if (!source) return NextResponse.json({ error: "Not found" }, { status: 404 });

    const clone = await prisma.parentGoalLibraryItem.create({
      data: {
        title:       `${source.title} (Copy)`,
        description: source.description,
        domain:      source.domain,
        category:    source.category,
        skillArea:   source.skillArea,
        notes:       source.notes,
        isActive:    true,
        usageCount:  0,
        createdById: session.user.id,
      },
    });

    return NextResponse.json(clone, { status: 201 });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Failed to clone" }, { status: 500 });
  }
}
