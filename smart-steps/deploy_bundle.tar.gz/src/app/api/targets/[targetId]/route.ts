import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { Prisma } from "@prisma/client";
import { prisma } from "@/lib/db";
import { auditLog } from "@/lib/auditLogger";

export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ targetId: string }> }
) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const role = (session.user as { role?: string }).role;
  if (role === "RBT") return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const { targetId } = await params;
  try {
    const body = await req.json() as {
      definition?: string;
      phase?: string;
      masteryRule?: Record<string, unknown>;
    };
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const updated = await (prisma.target.update as any)({
      where: { id: targetId },
      data: {
        ...(body.definition && { definition: body.definition }),
        ...(body.phase && { phase: body.phase }),
        ...(body.masteryRule && { masteryRule: body.masteryRule as Prisma.InputJsonValue }),
        updatedAt: new Date(),
      },
    });
    await auditLog(session.user.id!, "UPDATE_TARGET", "Target", targetId, { changes: body });
    return NextResponse.json(updated);
  } catch {
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}

export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ targetId: string }> }
) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const role = (session.user as { role?: string }).role;
  if (role !== "ADMIN" && role !== "BCBA") return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const { targetId } = await params;
  try {
    await prisma.target.delete({ where: { id: targetId } });
    await auditLog(session.user.id!, "DELETE_RECORD", "Target", targetId);
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}
