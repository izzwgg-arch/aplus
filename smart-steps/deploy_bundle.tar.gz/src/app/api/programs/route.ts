import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { prisma } from "@/lib/db";
import { auditLog } from "@/lib/auditLogger";

function mockPrograms(clientId: string) {
  return [
    { id: "p1", clientId, name: "Mand Training", domain: "Mand", description: "Requesting preferred items", isActive: true, targetCount: 3, masteredCount: 1 },
    { id: "p2", clientId, name: "Tact Training", domain: "Tact", description: "Labeling objects in environment", isActive: true, targetCount: 5, masteredCount: 2 },
    { id: "p3", clientId, name: "Imitation", domain: "Social", description: "Motor and vocal imitation", isActive: true, targetCount: 4, masteredCount: 4 },
  ];
}

export async function GET(req: Request) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const clientId = searchParams.get("clientId");
  if (!clientId) return NextResponse.json({ error: "clientId required" }, { status: 400 });

  try {
    const programs = await prisma.program.findMany({
      where: { clientId },
      orderBy: { createdAt: "asc" },
      include: { _count: { select: { targets: true } } },
    });

    if (!programs.length) return NextResponse.json(mockPrograms(clientId));

    const withCounts = await Promise.all(
      programs.map(async (p) => {
        const masteredCount = await prisma.target.count({
          where: { programId: p.id, phase: "MASTERED" },
        });
        return {
          id: p.id,
          clientId: p.clientId,
          name: p.name,
          domain: p.domain,
          description: "",
          isActive: p.isActive,
          targetCount: p._count.targets,
          masteredCount,
        };
      })
    );
    return NextResponse.json(withCounts);
  } catch {
    return NextResponse.json(mockPrograms(clientId));
  }
}

export async function POST(req: Request) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const role = (session.user as { role?: string }).role;
  if (role === "RBT") return NextResponse.json({ error: "Forbidden — BCBA/Admin only" }, { status: 403 });

  try {
    const body = await req.json() as { clientId: string; name: string; domain: string; description?: string };
    const program = await prisma.program.create({
      data: { clientId: body.clientId, name: body.name, domain: body.domain },
    });
    await auditLog(session.user.id!, "UPDATE_PROGRAM", "Program", program.id, { action: "create" });
    return NextResponse.json(program, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}
