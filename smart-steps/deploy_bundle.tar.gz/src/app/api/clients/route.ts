import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { prisma } from "@/lib/db";

function mockClients() {
  return [
    { id: "1", name: "Alex J.", photoUrl: null, dob: "2018-05-12", age: 7, diagnosis: ["ASD"], assignedRbt: "Jordan", assignedBcba: "Dr. Smith", lastSession: "2h ago", progressPct: 78 },
    { id: "2", name: "Sam K.", photoUrl: null, dob: "2019-11-03", age: 6, diagnosis: ["ASD", "ADHD"], assignedRbt: "Casey", assignedBcba: "Dr. Smith", lastSession: "1d ago", progressPct: 92 },
    { id: "3", name: "Riley M.", photoUrl: null, dob: "2017-02-28", age: 8, diagnosis: ["ASD"], assignedRbt: "Jordan", assignedBcba: undefined, lastSession: "Today", progressPct: 65 },
  ];
}

export async function GET() {
  const session = await auth();
  if (!session?.user?.id) {
    return NextResponse.json(mockClients());
  }

  try {
    const role = (session.user as { role?: string }).role;
    const isAdmin = role === "ADMIN" || role === "BCBA";

    const clients = await prisma.client.findMany({
      where: isAdmin
        ? undefined
        : { assignments: { some: { userId: session.user!.id } } },
      orderBy: { updatedAt: "desc" },
      include: {
        assignments: { include: { user: { select: { name: true } } } },
        sessions: { take: 1, orderBy: { startedAt: "desc" } },
      },
    });

    const now = new Date();
    const list = clients.map((c) => {
      const age = now.getFullYear() - c.dob.getFullYear();
      const rbt = c.assignments.find((a) => a.role === "RBT")?.user?.name;
      const bcba = c.assignments.find((a) => a.role === "BCBA")?.user?.name;
      const lastS = c.sessions[0];
      let lastSession: string | undefined;
      if (lastS) {
        const diff = now.getTime() - lastS.startedAt.getTime();
        if (diff < 3600000) lastSession = `${Math.floor(diff / 60000)}m ago`;
        else if (diff < 86400000) lastSession = "Today";
        else lastSession = `${Math.floor(diff / 86400000)}d ago`;
      }
      return {
        id: c.id,
        name: c.name,
        photoUrl: c.photoUrl,
        dob: c.dob.toISOString().slice(0, 10),
        age,
        diagnosis: c.diagnosis,
        assignedRbt: rbt ?? undefined,
        assignedBcba: bcba ?? undefined,
        lastSession,
        progressPct: 0,
      };
    });
    return NextResponse.json(list.length ? list : mockClients());
  } catch {
    return NextResponse.json(mockClients());
  }
}
