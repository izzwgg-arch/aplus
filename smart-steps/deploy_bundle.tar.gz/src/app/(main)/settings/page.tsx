"use client";

import { useEffect } from "react";
import { motion } from "framer-motion";
import { Moon, Sun, Monitor } from "lucide-react";
import { useThemeStore } from "@/store/themeStore";
import { toast } from "sonner";

export default function SettingsPage() {
  const { theme, setTheme, resolved } = useThemeStore();

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", resolved);
  }, [resolved]);

  const handleTheme = (t: "dark" | "light" | "system") => {
    setTheme(t);
    toast.success(`Theme: ${t}`);
  };

  return (
    <div className="p-6 md:p-8">
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
        <h1 className="text-2xl font-bold text-[var(--foreground)]">Settings</h1>
        <p className="text-zinc-500">Theme, notifications, account — 2026 polish.</p>
      </motion.div>

      <motion.section
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-card rounded-2xl p-6"
      >
        <h2 className="mb-4 text-lg font-semibold text-[var(--foreground)]">Appearance</h2>
        <p className="mb-4 text-sm text-zinc-500">Dark / light / system — default dark for that premium vibe.</p>
        <div className="flex flex-wrap gap-3">
          <button
            type="button"
            onClick={() => handleTheme("dark")}
            className={`tap-target flex items-center gap-2 rounded-xl px-4 py-3 transition-all ${
              theme === "dark"
                ? "bg-[var(--accent-cyan)]/20 text-[var(--accent-cyan)] ring-1 ring-[var(--accent-cyan)]/50"
                : "bg-[var(--glass-bg)] text-zinc-400 hover:text-[var(--foreground)]"
            }`}
          >
            <Moon className="h-5 w-5" />
            Dark
          </button>
          <button
            type="button"
            onClick={() => handleTheme("light")}
            className={`tap-target flex items-center gap-2 rounded-xl px-4 py-3 transition-all ${
              theme === "light"
                ? "bg-[var(--accent-cyan)]/20 text-[var(--accent-cyan)] ring-1 ring-[var(--accent-cyan)]/50"
                : "bg-[var(--glass-bg)] text-zinc-400 hover:text-[var(--foreground)]"
            }`}
          >
            <Sun className="h-5 w-5" />
            Light
          </button>
          <button
            type="button"
            onClick={() => handleTheme("system")}
            className={`tap-target flex items-center gap-2 rounded-xl px-4 py-3 transition-all ${
              theme === "system"
                ? "bg-[var(--accent-cyan)]/20 text-[var(--accent-cyan)] ring-1 ring-[var(--accent-cyan)]/50"
                : "bg-[var(--glass-bg)] text-zinc-400 hover:text-[var(--foreground)]"
            }`}
          >
            <Monitor className="h-5 w-5" />
            System
          </button>
        </div>
      </motion.section>

      <motion.section
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.05 }}
        className="mt-6 glass-card rounded-2xl p-6"
      >
        <h2 className="mb-4 text-lg font-semibold text-[var(--foreground)]">Account</h2>
        <p className="text-sm text-zinc-500">Managed via A+ Center SSO. Sign out below to return to the main app.</p>
      </motion.section>

      <motion.section
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="mt-6 glass-card rounded-2xl p-6"
      >
        <h2 className="mb-4 text-lg font-semibold text-[var(--foreground)]">PWA & offline</h2>
        <p className="text-sm text-zinc-500">Install prompt, offline indicator, and sync queue — active when you use the app offline.</p>
      </motion.section>
    </div>
  );
}
