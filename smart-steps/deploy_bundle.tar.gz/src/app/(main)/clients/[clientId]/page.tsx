"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
} from "recharts";
import {
  ArrowLeft,
  BookOpen,
  Brain,
  Calendar,
  ChevronRight,
  FileText,
  Target,
  TrendingUp,
  User,
} from "lucide-react";

type ClientDetail = {
  id: string;
  name: string;
  photoUrl?: string | null;
  dob: string;
  age: number;
  diagnosis: string[];
  assignedRbt?: string;
  assignedBcba?: string;
  masteredTargets: number;
  totalTargets: number;
  progressPct: number;
  sessionsThisWeek: number;
  lastSessionAt?: string;
  chartData: { date: string; correct: number; total: number; pct: number }[];
  behaviorBreakdown: { name: string; count: number }[];
};

async function fetchClientDetail(clientId: string): Promise<ClientDetail> {
  const res = await fetch(`/api/clients/${clientId}`);
  if (res.ok) {
    const data = await res.json();
    return data;
  }
  return getMockClientDetail(clientId);
}

function getMockClientDetail(clientId: string): ClientDetail {
  return {
    id: clientId,
    name: "Alex J.",
    photoUrl: null,
    dob: "2018-05-12",
    age: 7,
    diagnosis: ["ASD"],
    assignedRbt: "Jordan",
    assignedBcba: "Dr. Smith",
    masteredTargets: 12,
    totalTargets: 18,
    progressPct: 67,
    sessionsThisWeek: 4,
    lastSessionAt: new Date().toISOString(),
    chartData: [
      { date: "Mon", correct: 8, total: 10, pct: 80 },
      { date: "Tue", correct: 7, total: 10, pct: 70 },
      { date: "Wed", correct: 9, total: 10, pct: 90 },
      { date: "Thu", correct: 8, total: 10, pct: 80 },
      { date: "Fri", correct: 10, total: 10, pct: 100 },
    ],
    behaviorBreakdown: [
      { name: "Correct", count: 42 },
      { name: "Prompted", count: 8 },
      { name: "Incorrect", count: 2 },
    ],
  };
}

type Insight = { type: string; severity: string; title: string; description: string; recommendation: string; icon: string };

export default function ClientHubPage() {
  const params = useParams();
  const clientId = String(params.clientId ?? "");
  const { data: client, isLoading } = useQuery({
    queryKey: ["client", clientId],
    queryFn: () => fetchClientDetail(clientId),
    enabled: !!clientId,
  });

  const { data: insights = [] } = useQuery<Insight[]>({
    queryKey: ["insights", clientId],
    queryFn: async () => {
      const res = await fetch(`/api/insights?clientId=${clientId}`);
      if (!res.ok) return [];
      return res.json();
    },
    enabled: !!clientId,
  });

  if (isLoading || !client) {
    return (
      <div className="p-6 md:p-8">
        <div className="glass-card skeleton h-64 w-full rounded-2xl" />
        <div className="mt-6 grid gap-4 md:grid-cols-2">
          <div className="glass-card skeleton h-64 rounded-2xl" />
          <div className="glass-card skeleton h-64 rounded-2xl" />
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 md:p-8">
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between"
      >
        <div className="flex items-center gap-4">
          <Link
            href="/clients"
            className="tap-target rounded-xl p-2 text-zinc-400 hover:bg-[var(--glass-bg)] hover:text-[var(--foreground)]"
          >
            <ArrowLeft className="h-5 w-5" />
          </Link>
          <div className="h-14 w-14 shrink-0 overflow-hidden rounded-2xl bg-[var(--glass-border)]">
            {client.photoUrl ? (
              <img src={client.photoUrl} alt="" className="h-full w-full object-cover" />
            ) : (
              <div className="flex h-full w-full items-center justify-center text-2xl font-bold text-[var(--accent-cyan)]">
                <User className="h-7 w-7" />
              </div>
            )}
          </div>
          <div>
            <h1 className="text-2xl font-bold text-[var(--foreground)]">{client.name}</h1>
            <p className="text-sm text-zinc-500">
              Age {client.age} · {client.diagnosis.join(", ")}
            </p>
            <p className="mt-1 text-xs text-zinc-400">
              {client.assignedRbt && `RBT: ${client.assignedRbt}`}
              {client.assignedBcba && ` · BCBA: ${client.assignedBcba}`}
            </p>
          </div>
        </div>
        <Link
          href={`/clients/${clientId}/session/new`}
          className="btn-primary tap-target inline-flex items-center gap-2 rounded-xl px-6 py-3"
        >
          <Target className="h-5 w-5" />
          Start session
        </Link>
      </motion.div>

      {/* Quick stats — mastery-glow-up */}
      <motion.section
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.05 }}
        className="mb-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4"
      >
        <div className="glass-card flex items-center gap-4 rounded-2xl p-4">
          <div className="rounded-xl bg-[var(--accent-cyan)]/20 p-3">
            <Target className="h-6 w-6 text-[var(--accent-cyan)]" />
          </div>
          <div>
            <p className="text-2xl font-bold text-[var(--foreground)]">
              {client.masteredTargets}/{client.totalTargets}
            </p>
            <p className="text-xs text-zinc-500">Targets mastered</p>
          </div>
        </div>
        <div className="glass-card flex items-center gap-4 rounded-2xl p-4">
          <div className="rounded-xl bg-[var(--accent-purple)]/20 p-3">
            <TrendingUp className="h-6 w-6 text-[var(--accent-purple)]" />
          </div>
          <div>
            <p className="text-2xl font-bold text-[var(--foreground)]">{client.progressPct}%</p>
            <p className="text-xs text-zinc-500">Overall progress</p>
          </div>
        </div>
        <div className="glass-card flex items-center gap-4 rounded-2xl p-4">
          <div className="rounded-xl bg-[var(--accent-pink)]/20 p-3">
            <Calendar className="h-6 w-6 text-[var(--accent-pink)]" />
          </div>
          <div>
            <p className="text-2xl font-bold text-[var(--foreground)]">{client.sessionsThisWeek}</p>
            <p className="text-xs text-zinc-500">Sessions this week</p>
          </div>
        </div>
        <div className="glass-card flex items-center gap-4 rounded-2xl p-4">
          <div className="rounded-xl bg-emerald-500/20 p-3">
            <span className="text-lg">🔥</span>
          </div>
          <div>
            <p className="text-2xl font-bold text-[var(--foreground)]">
              {client.lastSessionAt ? "Active" : "—"}
            </p>
            <p className="text-xs text-zinc-500">Last session</p>
          </div>
        </div>
      </motion.section>

      {/* Charts — data that slaps */}
      <div className="grid gap-6 lg:grid-cols-2">
        <motion.section
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="glass-card overflow-hidden rounded-2xl p-4"
        >
          <h2 className="mb-4 text-lg font-semibold text-[var(--foreground)]">
            % correct (this week)
          </h2>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={client.chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--glass-border)" />
                <XAxis dataKey="date" stroke="var(--foreground)" fontSize={12} />
                <YAxis stroke="var(--foreground)" fontSize={12} domain={[0, 100]} />
                <Tooltip
                  contentStyle={{
                    background: "var(--glass-bg)",
                    border: "1px solid var(--glass-border)",
                    borderRadius: 12,
                  }}
                  formatter={(value: number) => [`${value}%`, "Correct"]}
                />
                <Line
                  type="monotone"
                  dataKey="pct"
                  stroke="var(--accent-cyan)"
                  strokeWidth={2}
                  dot={{ fill: "var(--accent-cyan)", r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </motion.section>

        <motion.section
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="glass-card overflow-hidden rounded-2xl p-4"
        >
          <h2 className="mb-4 text-lg font-semibold text-[var(--foreground)]">
            Trial breakdown
          </h2>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={client.behaviorBreakdown} layout="vertical" margin={{ left: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--glass-border)" />
                <XAxis type="number" stroke="var(--foreground)" fontSize={12} />
                <YAxis type="category" dataKey="name" stroke="var(--foreground)" fontSize={12} width={80} />
                <Tooltip
                  contentStyle={{
                    background: "var(--glass-bg)",
                    border: "1px solid var(--glass-border)",
                    borderRadius: 12,
                  }}
                />
                <Bar dataKey="count" fill="var(--accent-purple)" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </motion.section>
      </div>

      {/* Quick navigation cards */}
      <motion.section
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-8 grid gap-3 sm:grid-cols-3"
      >
        {[
          { href: `/clients/${clientId}/programs`, icon: BookOpen, label: "Programs & Targets", sub: "View skill programs", color: "var(--accent-cyan)" },
          { href: `/clients/${clientId}/behavior-plan`, icon: Brain, label: "Behavior Plan", sub: "BIP / intervention", color: "var(--accent-purple)" },
          { href: `/reports?clientId=${clientId}`, icon: FileText, label: "Reports", sub: "Progress & SOAP notes", color: "#34d399" },
        ].map((item) => (
          <Link key={item.href} href={item.href}>
            <motion.div
              whileHover={{ y: -2 }}
              className="glass-card flex items-center gap-3 rounded-2xl p-4 hover:shadow-[var(--glow-cyan)] transition-shadow"
            >
              <div className="rounded-xl p-2.5" style={{ background: `color-mix(in srgb, ${item.color} 15%, transparent)` }}>
                <item.icon className="h-5 w-5" style={{ color: item.color }} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-[var(--foreground)] text-sm">{item.label}</p>
                <p className="text-xs text-zinc-500">{item.sub}</p>
              </div>
              <ChevronRight className="h-4 w-4 text-zinc-600" />
            </motion.div>
          </Link>
        ))}
      </motion.section>

      {/* AI Insights */}
      {insights.length > 0 && (
        <motion.section
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
          className="mt-8"
        >
          <h2 className="mb-3 flex items-center gap-2 text-lg font-semibold text-[var(--foreground)]">
            <Brain className="h-5 w-5 text-[var(--accent-purple)]" />
            Clinical insights
          </h2>
          <div className="space-y-3">
            {insights.slice(0, 4).map((ins, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.25 + i * 0.05 }}
                className={`glass-card rounded-2xl p-4 border-l-2 ${
                  ins.severity === "warning"
                    ? "border-amber-400"
                    : ins.severity === "critical"
                    ? "border-[var(--accent-pink)]"
                    : "border-[var(--accent-cyan)]"
                }`}
              >
                <div className="flex items-start gap-3">
                  <span className="text-xl shrink-0">{ins.icon}</span>
                  <div>
                    <p className="font-semibold text-[var(--foreground)] text-sm">{ins.title}</p>
                    <p className="text-xs text-zinc-400 mt-0.5">{ins.description}</p>
                    <p className="text-xs text-[var(--accent-cyan)] mt-1">{ins.recommendation}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.section>
      )}
    </div>
  );
}
