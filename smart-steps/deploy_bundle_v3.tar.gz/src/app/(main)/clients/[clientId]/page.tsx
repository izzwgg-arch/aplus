"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar,
} from "recharts";
import {
  ArrowLeft, BookOpen, Brain, Calendar, ChevronRight, ClipboardList, Edit2, FileText, Target, TrendingUp, User,
} from "lucide-react";

type ClientDetail = {
  id: string;
  name: string;
  photoUrl?: string | null;
  dob: string;
  age: number;
  diagnosis: string[];
  guardianName?: string | null;
  guardianEmail?: string | null;
  assignedRbt?: string;
  assignedBcba?: string;
  masteredTargets: number;
  totalTargets: number;
  progressPct: number;
  sessionsThisWeek: number;
  lastSessionAt?: string;
  chartData: { date: string; correct: number; total: number; pct: number }[];
  behaviorBreakdown: { name: string; count: number }[];
};

export default function ClientHubPage() {
  const params = useParams();
  const clientId = String(params.clientId ?? "");

  const { data: client, isLoading, error } = useQuery<ClientDetail>({
    queryKey: ["client", clientId],
    queryFn: async () => {
      const res = await fetch(`/api/clients/${clientId}`);
      if (!res.ok) throw new Error("Failed to load client");
      return res.json();
    },
    enabled: !!clientId,
  });

  if (isLoading || !client) {
    return (
      <div className="p-6 md:p-8">
        <div className="glass-card skeleton h-32 w-full rounded-2xl mb-6" />
        <div className="grid gap-4 sm:grid-cols-4">
          {[1,2,3,4].map((i) => <div key={i} className="glass-card skeleton h-24 rounded-2xl" />)}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6 md:p-8">
        <div className="glass-card rounded-2xl p-8 text-center border border-[var(--accent-pink)]/30">
          <p className="text-[var(--accent-pink)] font-medium">Failed to load client profile</p>
          <p className="text-zinc-500 text-sm mt-1">Check your database connection or try refreshing</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 md:p-8">
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between"
      >
        <div className="flex items-center gap-4">
          <Link
            href="/clients"
            className="tap-target rounded-xl p-2 text-zinc-400 hover:bg-[var(--glass-bg)] hover:text-[var(--foreground)]"
          >
            <ArrowLeft className="h-5 w-5" />
          </Link>
          <div className="h-14 w-14 shrink-0 overflow-hidden rounded-2xl bg-[var(--glass-border)] flex items-center justify-center text-2xl font-bold text-[var(--accent-cyan)]">
            {client.photoUrl
              ? <img src={client.photoUrl} alt="" className="h-full w-full object-cover" />
              : client.name.slice(0, 1).toUpperCase()
            }
          </div>
          <div>
            <h1 className="text-2xl font-bold text-[var(--foreground)]">{client.name}</h1>
            <p className="text-sm text-zinc-500">Age {client.age} · {client.diagnosis.join(", ")}</p>
            <p className="mt-0.5 text-xs text-zinc-400">
              {client.assignedRbt && `RBT: ${client.assignedRbt}`}
              {client.assignedBcba && ` · BCBA: ${client.assignedBcba}`}
            </p>
          </div>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Link
            href={`/clients/${clientId}/edit`}
            className="btn-secondary tap-target inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm"
          >
            <Edit2 className="h-4 w-4" />
            Edit
          </Link>
          <Link
            href={`/clients/${clientId}/session/new`}
            className="btn-primary tap-target inline-flex items-center gap-2 rounded-xl px-5 py-2.5 text-sm font-semibold"
          >
            <Target className="h-4 w-4" />
            Start session
          </Link>
        </div>
      </motion.div>

      {/* Quick stats */}
      <motion.section
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.05 }}
        className="mb-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4"
      >
        {[
          { icon: Target, label: "Targets mastered", value: `${client.masteredTargets}/${client.totalTargets}`, color: "var(--accent-cyan)" },
          { icon: TrendingUp, label: "Overall progress", value: `${client.progressPct}%`, color: "var(--accent-purple)" },
          { icon: Calendar, label: "Sessions this week", value: String(client.sessionsThisWeek), color: "var(--accent-pink)" },
          { icon: User, label: "Guardian", value: client.guardianName ?? "—", color: "#34d399" },
        ].map((stat) => (
          <div key={stat.label} className="glass-card flex items-center gap-4 rounded-2xl p-4">
            <div className="rounded-xl p-3" style={{ background: `color-mix(in srgb, ${stat.color} 15%, transparent)` }}>
              <stat.icon className="h-6 w-6" style={{ color: stat.color }} />
            </div>
            <div>
              <p className="text-2xl font-bold text-[var(--foreground)] truncate max-w-[120px]">{stat.value}</p>
              <p className="text-xs text-zinc-500">{stat.label}</p>
            </div>
          </div>
        ))}
      </motion.section>

      {/* Charts */}
      {(client.chartData.some((d) => d.total > 0) || client.behaviorBreakdown.length > 0) && (
        <div className="grid gap-6 lg:grid-cols-2 mb-8">
          {client.chartData.some((d) => d.total > 0) && (
            <motion.section
              initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
              className="glass-card overflow-hidden rounded-2xl p-4"
            >
              <h2 className="mb-4 text-sm font-semibold text-zinc-300">% Correct — last 5 days</h2>
              <div className="h-52">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={client.chartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--glass-border)" />
                    <XAxis dataKey="date" stroke="var(--foreground)" fontSize={11} />
                    <YAxis stroke="var(--foreground)" fontSize={11} domain={[0, 100]} />
                    <Tooltip
                      contentStyle={{ background: "var(--glass-bg)", border: "1px solid var(--glass-border)", borderRadius: 12 }}
                      formatter={(value) => [`${value}%`, "Correct"]}
                    />
                    <Line type="monotone" dataKey="pct" stroke="var(--accent-cyan)" strokeWidth={2} dot={{ fill: "var(--accent-cyan)", r: 4 }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </motion.section>
          )}

          {client.behaviorBreakdown.length > 0 && (
            <motion.section
              initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}
              className="glass-card overflow-hidden rounded-2xl p-4"
            >
              <h2 className="mb-4 text-sm font-semibold text-zinc-300">Trial breakdown</h2>
              <div className="h-52">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={client.behaviorBreakdown} layout="vertical" margin={{ left: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--glass-border)" />
                    <XAxis type="number" stroke="var(--foreground)" fontSize={11} />
                    <YAxis type="category" dataKey="name" stroke="var(--foreground)" fontSize={11} width={80} />
                    <Tooltip contentStyle={{ background: "var(--glass-bg)", border: "1px solid var(--glass-border)", borderRadius: 12 }} />
                    <Bar dataKey="count" fill="var(--accent-purple)" radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </motion.section>
          )}
        </div>
      )}

      {/* Navigation grid */}
      <motion.section
        initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
        className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4"
      >
        {[
          { href: `/clients/${clientId}/goals`, icon: Target, label: "Goals & Targets", sub: "Parent goals, sub-goals, targets", color: "var(--accent-cyan)" },
          { href: `/clients/${clientId}/assessments`, icon: ClipboardList, label: "Assessments", sub: "Assign and complete assessments", color: "var(--accent-purple)" },
          { href: `/clients/${clientId}/programs`, icon: BookOpen, label: "Programs", sub: "Skill programs and targets", color: "var(--accent-pink)" },
          { href: `/clients/${clientId}/behavior-plan`, icon: Brain, label: "Behavior Plan", sub: "BIP and intervention", color: "#34d399" },
          { href: `/clients/${clientId}/session/new`, icon: Target, label: "Start Session", sub: "Collect data now", color: "var(--accent-cyan)" },
          { href: `/reports?clientId=${clientId}`, icon: FileText, label: "Reports", sub: "Progress and SOAP notes", color: "#f59e0b" },
        ].map((item) => (
          <Link key={item.href} href={item.href}>
            <motion.div
              whileHover={{ y: -2 }}
              className="glass-card flex items-center gap-3 rounded-2xl p-4 hover:shadow-[var(--glow-cyan)] transition-shadow"
            >
              <div className="rounded-xl p-2.5 shrink-0" style={{ background: `color-mix(in srgb, ${item.color} 15%, transparent)` }}>
                <item.icon className="h-5 w-5" style={{ color: item.color }} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-[var(--foreground)] text-sm">{item.label}</p>
                <p className="text-xs text-zinc-500 truncate">{item.sub}</p>
              </div>
              <ChevronRight className="h-4 w-4 text-zinc-600 shrink-0" />
            </motion.div>
          </Link>
        ))}
      </motion.section>
    </div>
  );
}
