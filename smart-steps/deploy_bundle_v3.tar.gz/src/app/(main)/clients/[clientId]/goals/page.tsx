"use client";

import { useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowLeft, ChevronDown, ChevronRight, Plus, CheckCircle, Circle, Pencil, Trash2, Target, MoreVertical, X
} from "lucide-react";
import { toast } from "sonner";

type TargetRow = {
  id: string;
  definition: string;
  targetType: string;
  phase: string;
  isActive: boolean;
};

type SubGoal = {
  id: string;
  title: string;
  description?: string | null;
  status: string;
  sortOrder: number;
  targets: TargetRow[];
};

type ParentGoal = {
  id: string;
  title: string;
  description?: string | null;
  domain?: string | null;
  status: string;
  priority: number;
  targetDate?: string | null;
  notes?: string | null;
  subGoals: SubGoal[];
  targets: TargetRow[];
  program?: { id: string; name: string } | null;
};

const PHASE_COLORS: Record<string, string> = {
  BASELINE: "text-zinc-400",
  ACQUISITION: "text-[var(--accent-cyan)]",
  MAINTENANCE: "text-amber-400",
  GENERALIZATION: "text-[var(--accent-purple)]",
  MASTERED: "text-emerald-400",
};

const TARGET_TYPES: Record<string, string> = {
  DISCRETE_TRIAL: "DTT",
  TASK_ANALYSIS_CHAIN_FWD: "Task (Fwd)",
  TASK_ANALYSIS_CHAIN_BWD: "Task (Bwd)",
  TASK_ANALYSIS_CHAIN_TOTAL: "Task (Total)",
  COLD_PROBE: "Cold Probe",
  GEN_PROBE: "Gen. Probe",
};

function TargetItem({ target, clientId, goalId }: { target: TargetRow; clientId: string; goalId: string }) {
  const qc = useQueryClient();

  async function archiveTarget() {
    if (!confirm("Remove this target?")) return;
    const res = await fetch(`/api/targets/${target.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isActive: false }),
    });
    if (res.ok) {
      toast.success("Target removed");
      qc.invalidateQueries({ queryKey: ["goals", clientId] });
    }
  }

  return (
    <div className="flex items-center gap-3 rounded-xl border border-[var(--glass-border)] bg-[var(--background)]/40 px-3 py-2.5">
      <div className={`h-2 w-2 shrink-0 rounded-full ${target.phase === "MASTERED" ? "bg-emerald-400" : "bg-[var(--accent-cyan)]"}`} />
      <span className="flex-1 text-sm text-[var(--foreground)]">{target.definition}</span>
      <span className={`text-xs font-medium ${PHASE_COLORS[target.phase] ?? "text-zinc-400"}`}>{target.phase}</span>
      <span className="text-xs text-zinc-600">{TARGET_TYPES[target.targetType] ?? target.targetType}</span>
      <button type="button" onClick={archiveTarget} className="rounded-lg p-1.5 text-zinc-600 hover:text-[var(--accent-pink)] transition-colors">
        <X className="h-3.5 w-3.5" />
      </button>
    </div>
  );
}

function AddTargetInline({
  onAdd,
  parentGoalId,
  subGoalId,
  programId,
}: {
  onAdd: () => void;
  parentGoalId?: string;
  subGoalId?: string;
  programId?: string;
}) {
  const [open, setOpen] = useState(false);
  const [def, setDef] = useState("");
  const [type, setType] = useState("DISCRETE_TRIAL");
  const [saving, setSaving] = useState(false);

  async function save() {
    if (!def.trim()) return;
    setSaving(true);
    try {
      const res = await fetch("/api/targets", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          definition: def,
          targetType: type,
          parentGoalId: parentGoalId || null,
          subGoalId: subGoalId || null,
          programId: programId || null,
        }),
      });
      if (!res.ok) { const d = await res.json(); throw new Error(d.error); }
      toast.success("Target added");
      setDef("");
      setOpen(false);
      onAdd();
    } catch (err) {
      toast.error(String(err));
    } finally {
      setSaving(false);
    }
  }

  if (!open) {
    return (
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="flex items-center gap-2 rounded-xl border border-dashed border-[var(--glass-border)] px-3 py-2 text-xs text-zinc-500 hover:border-[var(--accent-cyan)]/50 hover:text-[var(--accent-cyan)] transition-colors w-full"
      >
        <Plus className="h-3.5 w-3.5" /> Add target
      </button>
    );
  }

  return (
    <div className="rounded-xl border border-[var(--accent-cyan)]/30 bg-[var(--glass-bg)] p-3 space-y-2">
      <input
        autoFocus
        type="text"
        value={def}
        onChange={(e) => setDef(e.target.value)}
        onKeyDown={(e) => { if (e.key === "Enter") save(); if (e.key === "Escape") setOpen(false); }}
        placeholder="Target definition (operational)…"
        className="field-input w-full text-sm"
      />
      <select value={type} onChange={(e) => setType(e.target.value)} className="field-input w-full text-sm">
        {Object.entries(TARGET_TYPES).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
      </select>
      <div className="flex gap-2">
        <button onClick={save} disabled={saving} className="btn-primary flex-1 rounded-xl py-1.5 text-sm disabled:opacity-60">
          {saving ? "Saving…" : "Add"}
        </button>
        <button onClick={() => setOpen(false)} className="btn-secondary rounded-xl px-3 py-1.5 text-sm">Cancel</button>
      </div>
    </div>
  );
}

function SubGoalRow({
  sg,
  clientId,
  goalId,
  onRefresh,
}: {
  sg: SubGoal;
  clientId: string;
  goalId: string;
  onRefresh: () => void;
}) {
  const [expanded, setExpanded] = useState(true);

  async function archive() {
    if (!confirm("Archive this sub-goal?")) return;
    const res = await fetch(`/api/clients/${clientId}/goals/${goalId}/subgoals/${sg.id}`, { method: "DELETE" });
    if (res.ok) { toast.success("Sub-goal archived"); onRefresh(); }
  }

  return (
    <div className="border border-[var(--glass-border)]/60 rounded-2xl overflow-hidden">
      <button
        type="button"
        onClick={() => setExpanded((v) => !v)}
        className="w-full flex items-center gap-3 px-4 py-3 bg-[var(--glass-bg)]/30 hover:bg-[var(--glass-bg)] transition-colors"
      >
        {expanded ? <ChevronDown className="h-4 w-4 text-zinc-500 shrink-0" /> : <ChevronRight className="h-4 w-4 text-zinc-500 shrink-0" />}
        <span className="flex-1 text-left text-sm font-medium text-[var(--foreground)]">{sg.title}</span>
        <span className="text-xs text-zinc-500">{sg.targets.length} target{sg.targets.length !== 1 ? "s" : ""}</span>
        <span className={`text-xs px-2 py-0.5 rounded-full ${sg.status === "MASTERED" ? "bg-emerald-500/20 text-emerald-400" : "bg-[var(--accent-cyan)]/20 text-[var(--accent-cyan)]"}`}>
          {sg.status}
        </span>
        <button
          type="button"
          onClick={(e) => { e.stopPropagation(); archive(); }}
          className="rounded-lg p-1.5 text-zinc-600 hover:text-[var(--accent-pink)] transition-colors"
        >
          <Trash2 className="h-3.5 w-3.5" />
        </button>
      </button>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <div className="p-3 space-y-2">
              {sg.description && <p className="text-xs text-zinc-500 px-1">{sg.description}</p>}
              {sg.targets.map((t) => <TargetItem key={t.id} target={t} clientId={clientId} goalId={goalId} />)}
              <AddTargetInline onAdd={onRefresh} subGoalId={sg.id} />
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function ParentGoalCard({
  goal,
  clientId,
  onRefresh,
}: {
  goal: ParentGoal;
  clientId: string;
  onRefresh: () => void;
}) {
  const [expanded, setExpanded] = useState(true);
  const [addingSubGoal, setAddingSubGoal] = useState(false);
  const [sgTitle, setSgTitle] = useState("");
  const [sgSaving, setSgSaving] = useState(false);

  async function archiveGoal() {
    if (!confirm("Archive this goal? All sub-goals will be hidden.")) return;
    const res = await fetch(`/api/clients/${clientId}/goals/${goal.id}`, { method: "DELETE" });
    if (res.ok) { toast.success("Goal archived"); onRefresh(); }
  }

  async function addSubGoal() {
    if (!sgTitle.trim()) return;
    setSgSaving(true);
    try {
      const res = await fetch(`/api/clients/${clientId}/goals/${goal.id}/subgoals`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title: sgTitle }),
      });
      if (!res.ok) throw new Error();
      toast.success("Sub-goal added");
      setSgTitle("");
      setAddingSubGoal(false);
      onRefresh();
    } catch {
      toast.error("Failed to add sub-goal");
    } finally {
      setSgSaving(false);
    }
  }

  const masteredTargets = [...goal.subGoals.flatMap((sg) => sg.targets), ...goal.targets].filter((t) => t.phase === "MASTERED").length;
  const totalTargets = [...goal.subGoals.flatMap((sg) => sg.targets), ...goal.targets].length;

  return (
    <motion.div
      layout
      className="glass-card rounded-2xl overflow-hidden"
    >
      <div
        className="flex items-start gap-3 p-4 cursor-pointer hover:bg-[var(--glass-bg)]/60 transition-colors"
        onClick={() => setExpanded((v) => !v)}
      >
        {expanded ? <ChevronDown className="h-5 w-5 text-zinc-400 shrink-0 mt-0.5" /> : <ChevronRight className="h-5 w-5 text-zinc-400 shrink-0 mt-0.5" />}
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <h3 className="font-semibold text-[var(--foreground)]">{goal.title}</h3>
            <div className="flex items-center gap-2 shrink-0">
              {goal.domain && (
                <span className="rounded-full bg-[var(--accent-purple)]/20 px-2.5 py-0.5 text-xs text-[var(--accent-purple)]">
                  {goal.domain}
                </span>
              )}
              <span className={`text-xs px-2 py-0.5 rounded-full ${
                goal.status === "MASTERED" ? "bg-emerald-500/20 text-emerald-400"
                : goal.status === "ON_HOLD" ? "bg-amber-500/20 text-amber-400"
                : "bg-[var(--accent-cyan)]/20 text-[var(--accent-cyan)]"
              }`}>
                {goal.status}
              </span>
            </div>
          </div>
          {goal.description && <p className="text-xs text-zinc-500 mt-0.5">{goal.description}</p>}
          <div className="mt-2 flex items-center gap-4 text-xs text-zinc-500">
            <span>{goal.subGoals.length} sub-goal{goal.subGoals.length !== 1 ? "s" : ""}</span>
            <span>{totalTargets} target{totalTargets !== 1 ? "s" : ""}</span>
            {totalTargets > 0 && (
              <span className="text-emerald-400">{masteredTargets}/{totalTargets} mastered</span>
            )}
            {goal.targetDate && (
              <span>Target: {new Date(goal.targetDate).toLocaleDateString()}</span>
            )}
          </div>
          {totalTargets > 0 && (
            <div className="mt-2 h-1 w-full rounded-full bg-[var(--glass-border)] overflow-hidden">
              <div
                className="h-full rounded-full bg-[var(--accent-cyan)]"
                style={{ width: `${Math.round((masteredTargets / totalTargets) * 100)}%` }}
              />
            </div>
          )}
        </div>
        <button
          type="button"
          onClick={(e) => { e.stopPropagation(); archiveGoal(); }}
          className="shrink-0 rounded-xl p-2 text-zinc-600 hover:text-[var(--accent-pink)] transition-colors"
        >
          <Trash2 className="h-4 w-4" />
        </button>
      </div>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-4 space-y-3">
              {goal.subGoals.map((sg) => (
                <SubGoalRow key={sg.id} sg={sg} clientId={clientId} goalId={goal.id} onRefresh={onRefresh} />
              ))}

              {/* Direct targets (no sub-goal) */}
              {goal.targets.map((t) => <TargetItem key={t.id} target={t} clientId={clientId} goalId={goal.id} />)}
              {goal.targets.length > 0 && <AddTargetInline onAdd={onRefresh} parentGoalId={goal.id} />}

              {/* Add sub-goal */}
              {addingSubGoal ? (
                <div className="rounded-2xl border border-[var(--accent-purple)]/30 bg-[var(--glass-bg)] p-3 space-y-2">
                  <input
                    autoFocus
                    type="text"
                    value={sgTitle}
                    onChange={(e) => setSgTitle(e.target.value)}
                    onKeyDown={(e) => { if (e.key === "Enter") addSubGoal(); if (e.key === "Escape") setAddingSubGoal(false); }}
                    placeholder="Sub-goal title…"
                    className="field-input w-full text-sm"
                  />
                  <div className="flex gap-2">
                    <button onClick={addSubGoal} disabled={sgSaving} className="btn-primary flex-1 rounded-xl py-1.5 text-sm disabled:opacity-60">
                      {sgSaving ? "Saving…" : "Add sub-goal"}
                    </button>
                    <button onClick={() => setAddingSubGoal(false)} className="btn-secondary rounded-xl px-3 py-1.5 text-sm">Cancel</button>
                  </div>
                </div>
              ) : (
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setAddingSubGoal(true)}
                    className="flex-1 flex items-center gap-2 rounded-xl border border-dashed border-[var(--glass-border)] px-3 py-2 text-xs text-zinc-500 hover:border-[var(--accent-purple)]/50 hover:text-[var(--accent-purple)] transition-colors"
                  >
                    <Plus className="h-3.5 w-3.5" /> Add sub-goal
                  </button>
                  {goal.subGoals.length === 0 && (
                    <AddTargetInline onAdd={onRefresh} parentGoalId={goal.id} />
                  )}
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

export default function GoalsPage() {
  const params = useParams();
  const clientId = String(params.clientId ?? "");
  const qc = useQueryClient();
  const [showNewGoalForm, setShowNewGoalForm] = useState(false);
  const [newGoal, setNewGoal] = useState({ title: "", description: "", domain: "", targetDate: "" });
  const [savingGoal, setSavingGoal] = useState(false);

  const { data: goals = [], isLoading, error } = useQuery<ParentGoal[]>({
    queryKey: ["goals", clientId],
    queryFn: async () => {
      const res = await fetch(`/api/clients/${clientId}/goals`);
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
    enabled: !!clientId,
  });

  function refresh() {
    qc.invalidateQueries({ queryKey: ["goals", clientId] });
  }

  async function createGoal(e: React.FormEvent) {
    e.preventDefault();
    if (!newGoal.title.trim()) return toast.error("Title required");
    setSavingGoal(true);
    try {
      const res = await fetch(`/api/clients/${clientId}/goals`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newGoal),
      });
      if (!res.ok) { const d = await res.json(); throw new Error(d.error); }
      toast.success("Goal created");
      setNewGoal({ title: "", description: "", domain: "", targetDate: "" });
      setShowNewGoalForm(false);
      refresh();
    } catch (err) {
      toast.error(String(err));
    } finally {
      setSavingGoal(false);
    }
  }

  return (
    <div className="p-6 md:p-8 max-w-3xl">
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="mb-8 flex items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <Link
            href={`/clients/${clientId}`}
            className="tap-target rounded-xl p-2 text-zinc-400 hover:bg-[var(--glass-bg)] hover:text-[var(--foreground)]"
          >
            <ArrowLeft className="h-5 w-5" />
          </Link>
          <div>
            <h1 className="text-2xl font-bold text-[var(--foreground)]">Goals & Targets</h1>
            <p className="text-zinc-500 text-sm">
              {goals.length} parent goal{goals.length !== 1 ? "s" : ""} · Hierarchy: Goal &rarr; Sub-goal &rarr; Target
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={() => setShowNewGoalForm((v) => !v)}
          className="btn-primary tap-target inline-flex items-center gap-2 rounded-xl px-5 py-2.5 text-sm font-semibold"
        >
          <Plus className="h-4 w-4" />
          New goal
        </button>
      </motion.div>

      <AnimatePresence>
        {showNewGoalForm && (
          <motion.form
            key="new-goal-form"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            onSubmit={createGoal}
            className="glass-card rounded-2xl p-5 mb-6 border border-[var(--accent-cyan)]/30 space-y-4"
          >
            <h2 className="font-semibold text-[var(--foreground)]">New parent goal</h2>

            <div>
              <label className="block text-sm font-medium text-zinc-300 mb-1.5">
                Goal title <span className="text-[var(--accent-pink)]">*</span>
              </label>
              <input
                required autoFocus
                type="text"
                value={newGoal.title}
                onChange={(e) => setNewGoal((p) => ({ ...p, title: e.target.value }))}
                placeholder="e.g. Improve expressive communication"
                className="field-input w-full"
              />
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className="block text-sm font-medium text-zinc-300 mb-1.5">Domain / category</label>
                <input
                  type="text"
                  value={newGoal.domain}
                  onChange={(e) => setNewGoal((p) => ({ ...p, domain: e.target.value }))}
                  placeholder="e.g. Communication, Social"
                  className="field-input w-full"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-zinc-300 mb-1.5">Target date (optional)</label>
                <input
                  type="date"
                  value={newGoal.targetDate}
                  onChange={(e) => setNewGoal((p) => ({ ...p, targetDate: e.target.value }))}
                  className="field-input w-full"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-zinc-300 mb-1.5">Description (optional)</label>
              <textarea
                value={newGoal.description}
                onChange={(e) => setNewGoal((p) => ({ ...p, description: e.target.value }))}
                rows={2}
                placeholder="Long-term objective description…"
                className="field-input w-full resize-none"
              />
            </div>

            <div className="flex gap-3">
              <button type="submit" disabled={savingGoal} className="btn-primary flex-1 rounded-xl py-2.5 font-semibold disabled:opacity-60">
                {savingGoal ? "Creating…" : "Create goal"}
              </button>
              <button type="button" onClick={() => setShowNewGoalForm(false)} className="btn-secondary rounded-xl px-5 py-2.5">Cancel</button>
            </div>
          </motion.form>
        )}
      </AnimatePresence>

      {error && (
        <div className="rounded-2xl border border-[var(--accent-pink)]/30 bg-[var(--accent-pink)]/10 p-4 text-sm text-[var(--accent-pink)] mb-4">
          Failed to load goals. Check database connection.
        </div>
      )}

      {isLoading ? (
        <div className="space-y-4">
          {[1, 2].map((i) => <div key={i} className="glass-card skeleton h-32 rounded-2xl" />)}
        </div>
      ) : goals.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-[var(--glass-border)] py-16 text-center">
          <Target className="h-10 w-10 text-zinc-600 mx-auto mb-3" />
          <p className="text-zinc-400 font-medium mb-1">No goals yet</p>
          <p className="text-zinc-600 text-sm mb-4">Create a parent goal, then add sub-goals and targets beneath it.</p>
          <button
            type="button"
            onClick={() => setShowNewGoalForm(true)}
            className="btn-primary inline-flex items-center gap-2 rounded-xl px-5 py-2.5 text-sm font-semibold"
          >
            <Plus className="h-4 w-4" /> Create first goal
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {goals.map((goal) => (
            <ParentGoalCard key={goal.id} goal={goal} clientId={clientId} onRefresh={refresh} />
          ))}
        </div>
      )}
    </div>
  );
}
