"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { FileText, Download, Mail, FileSpreadsheet } from "lucide-react";
import { toast } from "sonner";

type ReportType = "progress" | "soap" | "session_summary" | "behavior";

const REPORT_TYPES: { id: ReportType; label: string; desc: string; icon: typeof FileText }[] = [
  { id: "progress", label: "Progress report", desc: "Trials, mastery, trends", icon: FileText },
  { id: "soap", label: "SOAP note", desc: "Subjective, Objective, Assessment, Plan", icon: FileText },
  { id: "session_summary", label: "Session summary", desc: "Per-session trials & notes", icon: FileSpreadsheet },
  { id: "behavior", label: "Behavior summary", desc: "Frequency, ABC, intensity", icon: FileText },
];

const REPORT_TO_TYPE: Record<string, string> = {
  progress: "progress",
  soap: "progress",
  session_summary: "trials",
  behavior: "behaviors",
};

export default function ReportsPage() {
  const [selectedClient, setSelectedClient] = useState<string | null>(null);
  const [selectedReport, setSelectedReport] = useState<ReportType>("progress");
  const [dateRange, setDateRange] = useState({
    start: new Date(Date.now() - 30 * 86400000).toISOString().slice(0, 10),
    end: new Date().toISOString().slice(0, 10),
  });
  const [exporting, setExporting] = useState(false);

  const handleExport = async (format: "csv" | "json") => {
    setExporting(true);
    const type = REPORT_TO_TYPE[selectedReport] ?? "progress";
    const params = new URLSearchParams({ format, type });
    if (selectedClient) params.set("clientId", selectedClient);
    if (dateRange.start) params.set("start", dateRange.start);
    if (dateRange.end) params.set("end", dateRange.end);

    try {
      const res = await fetch(`/api/reports?${params.toString()}`);
      if (!res.ok) throw new Error("Failed");

      if (format === "csv") {
        const blob = await res.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `smart-steps-${type}-${dateRange.start ?? "report"}.csv`;
        a.click();
        URL.revokeObjectURL(url);
        toast.success("CSV downloaded.");
      } else {
        const data = await res.json();
        toast.success(`Report: ${data.total ?? data.count ?? 0} records found.`);
      }
    } catch {
      toast.error("Export failed. Try again.");
    } finally {
      setExporting(false);
    }
  };

  const handleEmail = () => {
    toast.success("Report will be emailed to authorized recipients. (Configure SMTP in Settings.)");
  };

  return (
    <div className="p-6 md:p-8">
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
        <h1 className="text-2xl font-bold text-[var(--foreground)]">Reports & notes</h1>
        <p className="text-zinc-500">Progress reports, SOAP notes, export PDF/CSV — audit-ready.</p>
      </motion.div>

      <div className="grid gap-6 lg:grid-cols-2">
        <motion.section
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-card rounded-2xl p-6"
        >
          <h2 className="mb-4 text-lg font-semibold text-[var(--foreground)]">Report type</h2>
          <div className="space-y-2">
            {REPORT_TYPES.map((r) => (
              <button
                key={r.id}
                type="button"
                onClick={() => setSelectedReport(r.id)}
                className={`tap-target flex w-full items-center gap-3 rounded-xl border p-3 text-left transition-colors ${
                  selectedReport === r.id
                    ? "border-[var(--accent-cyan)]/40 bg-[var(--accent-cyan)]/10"
                    : "border-[var(--glass-border)] bg-[var(--glass-bg)] hover:border-[var(--accent-cyan)]/30"
                }`}
              >
                <r.icon className="h-5 w-5 shrink-0 text-[var(--accent-purple)]" />
                <div>
                  <p className="font-medium text-[var(--foreground)]">{r.label}</p>
                  <p className="text-xs text-zinc-500">{r.desc}</p>
                </div>
                {selectedReport === r.id && (
                  <span className="ml-auto rounded-full bg-[var(--accent-cyan)]/20 px-2 py-0.5 text-xs text-[var(--accent-cyan)]">
                    Selected
                  </span>
                )}
              </button>
            ))}
          </div>
        </motion.section>

        <motion.section
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.05 }}
          className="glass-card rounded-2xl p-6"
        >
          <h2 className="mb-4 text-lg font-semibold text-[var(--foreground)]">Options</h2>
          <div className="space-y-4">
            <div>
              <label className="mb-1 block text-sm text-zinc-400">Client</label>
              <select
                value={selectedClient ?? ""}
                onChange={(e) => setSelectedClient(e.target.value || null)}
                className="w-full rounded-xl border border-[var(--glass-border)] bg-[var(--glass-bg)] px-4 py-2.5 text-[var(--foreground)]"
              >
                <option value="">All clients</option>
                <option value="1">Alex J.</option>
                <option value="2">Sam K.</option>
                <option value="3">Riley M.</option>
              </select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="mb-1 block text-sm text-zinc-400">Start date</label>
                <input
                  type="date"
                  value={dateRange.start}
                  onChange={(e) => setDateRange((r) => ({ ...r, start: e.target.value }))}
                  className="w-full rounded-xl border border-[var(--glass-border)] bg-[var(--glass-bg)] px-4 py-2.5 text-[var(--foreground)]"
                />
              </div>
              <div>
                <label className="mb-1 block text-sm text-zinc-400">End date</label>
                <input
                  type="date"
                  value={dateRange.end}
                  onChange={(e) => setDateRange((r) => ({ ...r, end: e.target.value }))}
                  className="w-full rounded-xl border border-[var(--glass-border)] bg-[var(--glass-bg)] px-4 py-2.5 text-[var(--foreground)]"
                />
              </div>
            </div>
          </div>
        </motion.section>
      </div>

      <motion.section
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="mt-8"
      >
        <div className="glass-card flex flex-wrap items-center gap-4 rounded-2xl p-6">
          <span className="text-sm font-medium text-[var(--foreground)]">Export</span>
          <button
            type="button"
            onClick={() => handleExport("json")}
            disabled={exporting}
            className="btn-primary tap-target inline-flex items-center gap-2 rounded-xl px-4 py-2.5 disabled:opacity-50"
          >
            <Download className="h-4 w-4" />
            {exporting ? "Generating…" : "Preview JSON"}
          </button>
          <button
            type="button"
            onClick={() => handleExport("csv")}
            disabled={exporting}
            className="tap-target inline-flex items-center gap-2 rounded-xl border border-[var(--glass-border)] bg-[var(--glass-bg)] px-4 py-2.5 text-[var(--foreground)] hover:bg-white/5 disabled:opacity-50"
          >
            <FileSpreadsheet className="h-4 w-4" />
            Export CSV
          </button>
          <button
            type="button"
            onClick={handleEmail}
            className="tap-target inline-flex items-center gap-2 rounded-xl border border-[var(--glass-border)] bg-[var(--glass-bg)] px-4 py-2.5 text-[var(--foreground)] hover:bg-white/5"
          >
            <Mail className="h-4 w-4" />
            Email report
          </button>
        </div>
      </motion.section>

      <p className="mt-6 text-center text-xs text-zinc-500">
        Audit logs: who entered/edited/deleted what (timestamps + user) — available in Settings.
      </p>
    </div>
  );
}
