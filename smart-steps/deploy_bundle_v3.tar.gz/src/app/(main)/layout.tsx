"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { usePathname } from "next/navigation";
import { signOut, useSession } from "next-auth/react";
import { motion } from "framer-motion";
import { LayoutDashboard, Users, FileBarChart, Settings, Wifi, WifiOff, RefreshCw, ClipboardList } from "lucide-react";
import { getPendingCount, flushSyncQueue } from "@/lib/dexie";
import { toast } from "sonner";

const nav = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/clients", label: "Clients", icon: Users },
  { href: "/assessments", label: "Assessments", icon: ClipboardList },
  { href: "/reports", label: "Reports", icon: FileBarChart },
  { href: "/settings", label: "Settings", icon: Settings },
];

export default function MainLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const { data: session } = useSession();
  const [isOnline, setIsOnline] = useState(true);
  const [pendingCount, setPendingCount] = useState(0);
  const [syncing, setSyncing] = useState(false);

  useEffect(() => {
    setIsOnline(navigator.onLine);
    const on = () => setIsOnline(true);
    const off = () => setIsOnline(false);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    return () => { window.removeEventListener("online", on); window.removeEventListener("offline", off); };
  }, []);

  useEffect(() => {
    getPendingCount().then(setPendingCount).catch(() => {});
    const interval = setInterval(() => getPendingCount().then(setPendingCount).catch(() => {}), 15000);
    return () => clearInterval(interval);
  }, []);

  async function handleSync() {
    if (syncing || !isOnline) return;
    setSyncing(true);
    try {
      const result = await flushSyncQueue();
      if (result.synced > 0) toast.success(`Synced ${result.synced} items.`);
      if (result.conflicts > 0) toast.warning(`${result.conflicts} conflict(s) — server wins.`);
      if (result.errors > 0) toast.error(`${result.errors} item(s) failed to sync.`);
      setPendingCount(0);
    } catch {
      toast.error("Sync failed. Will retry.");
    } finally {
      setSyncing(false);
    }
  }

  return (
    <div className="flex min-h-screen bg-[var(--background)]">
      <aside className="fixed inset-y-0 left-0 z-20 flex w-56 flex-col border-r border-[var(--glass-border)] bg-[var(--glass-bg)] backdrop-blur-xl">
        <div className="flex h-14 items-center gap-2 border-b border-[var(--glass-border)] px-4">
          <Link href="/dashboard" className="font-semibold tracking-tight text-[var(--foreground)]">
            Smart Steps
          </Link>
        </div>
        <nav className="flex-1 space-y-0.5 overflow-y-auto p-2">
          {nav.map((item) => {
            const active = pathname === item.href || pathname.startsWith(item.href + "/");
            const Icon = item.icon;
            return (
              <Link key={item.href} href={item.href} className="tap-target block">
                <motion.span
                  className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors ${
                    active
                      ? "bg-[var(--accent-cyan)]/20 text-[var(--accent-cyan)]"
                      : "text-zinc-400 hover:bg-white/5 hover:text-[var(--foreground)]"
                  }`}
                  whileHover={{ x: 2 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Icon className="h-5 w-5 shrink-0" />
                  {item.label}
                </motion.span>
              </Link>
            );
          })}
        </nav>

        <div className="px-3 py-2">
          <div className={`flex items-center gap-2 rounded-xl px-3 py-2 text-xs ${isOnline ? "text-emerald-400" : "text-[var(--accent-pink)]"}`}>
            {isOnline ? <Wifi className="h-3.5 w-3.5" /> : <WifiOff className="h-3.5 w-3.5" />}
            {isOnline ? "Online" : "Offline"}
          </div>
          {pendingCount > 0 && (
            <button
              type="button"
              onClick={handleSync}
              disabled={syncing || !isOnline}
              className="tap-target flex w-full items-center gap-2 rounded-xl px-3 py-2 text-xs text-amber-400 hover:bg-amber-400/10 disabled:opacity-50"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${syncing ? "animate-spin" : ""}`} />
              {syncing ? "Syncing…" : `${pendingCount} pending`}
            </button>
          )}
        </div>

        {session?.user && (
          <div className="border-t border-[var(--glass-border)] p-2">
            <div className="rounded-xl px-3 py-2">
              <p className="text-xs font-medium text-zinc-300 truncate">{session.user.name ?? session.user.email}</p>
              <p className="text-xs text-zinc-500">{(session.user as { role?: string }).role ?? "RBT"}</p>
            </div>
            <button
              type="button"
              onClick={() => signOut({ callbackUrl: "/login" })}
              className="tap-target w-full rounded-xl px-3 py-2 text-left text-sm text-zinc-400 hover:bg-white/5 hover:text-[var(--foreground)]"
            >
              Sign out
            </button>
          </div>
        )}
      </aside>
      <main className="min-h-screen flex-1 pl-56">
        {children}
      </main>
    </div>
  );
}
