"use client";

import { useParams } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend,
} from "recharts";
import { BookOpen, TrendingUp, Activity, Calendar, Lock } from "lucide-react";

// Parent portal — read-only, no auth required for demo (in production add parent-scoped auth)
type ClientDetail = {
  name: string;
  age: number;
  diagnosis: string[];
  progressData: { date: string; pct: number }[];
  behaviorData: { date: string; count: number }[];
  masteredTargets: number;
  totalTargets: number;
  recentSessions: { date: string; duration: number; note?: string }[];
};

function mockData(clientId: string): ClientDetail {
  const now = Date.now();
  return {
    name: "Learner",
    age: 7,
    diagnosis: ["ASD"],
    progressData: Array.from({ length: 8 }, (_, i) => ({
      date: new Date(now - (7 - i) * 7 * 86400000).toLocaleDateString("en-US", { month: "short", day: "numeric" }),
      pct: 40 + Math.round(Math.random() * 40 + i * 4),
    })),
    behaviorData: Array.from({ length: 8 }, (_, i) => ({
      date: new Date(now - (7 - i) * 7 * 86400000).toLocaleDateString("en-US", { month: "short", day: "numeric" }),
      count: Math.max(0, 8 - i + Math.round(Math.random() * 3)),
    })),
    masteredTargets: 7,
    totalTargets: 15,
    recentSessions: [
      { date: new Date(now - 86400000).toLocaleDateString(), duration: 45, note: "Great focus today!" },
      { date: new Date(now - 3 * 86400000).toLocaleDateString(), duration: 60 },
      { date: new Date(now - 6 * 86400000).toLocaleDateString(), duration: 50, note: "Worked on mand training." },
    ],
  };
}

const tooltipStyle = {
  backgroundColor: "rgba(15,15,20,0.95)",
  border: "1px solid rgba(255,255,255,0.08)",
  borderRadius: 12,
  color: "#e4e4e7",
};

export default function ParentPortalPage() {
  const params = useParams();
  const clientId = String(params.clientId ?? "");

  const { data: client, isLoading } = useQuery<ClientDetail>({
    queryKey: ["parent-client", clientId],
    queryFn: async () => {
      try {
        const res = await fetch(`/api/clients/${clientId}`);
        if (!res.ok) throw new Error("Not found");
        const raw = await res.json();
        return {
          name: raw.name ?? "Learner",
          age: raw.age ?? 0,
          diagnosis: raw.diagnosis ?? [],
          progressData: raw.progressData ?? mockData(clientId).progressData,
          behaviorData: raw.behaviorData ?? mockData(clientId).behaviorData,
          masteredTargets: raw.masteredTargets ?? 7,
          totalTargets: raw.totalTargets ?? 15,
          recentSessions: raw.recentSessions ?? mockData(clientId).recentSessions,
        };
      } catch {
        return mockData(clientId);
      }
    },
  });

  const data = client ?? mockData(clientId);

  return (
    <div className="min-h-dvh bg-[var(--background)]">
      {/* Header */}
      <header className="border-b border-[var(--glass-border)] bg-[var(--background)]/80 backdrop-blur-xl">
        <div className="mx-auto flex max-w-3xl items-center justify-between px-4 py-4">
          <div>
            <h1 className="font-bold text-[var(--foreground)]">Smart Steps ABA</h1>
            <p className="text-xs text-zinc-500">Parent &amp; Caregiver Portal</p>
          </div>
          <div className="flex items-center gap-1.5 rounded-full bg-[var(--glass-bg)] px-3 py-1.5 text-xs text-zinc-400">
            <Lock className="h-3 w-3" />
            Read-only
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-3xl px-4 py-8 space-y-6">
        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => <div key={i} className="glass-card skeleton h-32 rounded-2xl" />)}
          </div>
        ) : (
          <>
            {/* Learner card */}
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              className="glass-card rounded-2xl p-6"
            >
              <div className="flex items-center gap-4">
                <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-[var(--accent-cyan)]/20 to-[var(--accent-purple)]/20 text-2xl font-bold text-[var(--accent-cyan)]">
                  {data.name.slice(0, 1)}
                </div>
                <div>
                  <h2 className="text-xl font-bold text-[var(--foreground)]">{data.name}</h2>
                  <p className="text-sm text-zinc-500">Age {data.age}</p>
                  <div className="mt-1 flex flex-wrap gap-1">
                    {data.diagnosis.map((d) => (
                      <span key={d} className="rounded-full bg-[var(--accent-purple)]/20 px-2 py-0.5 text-xs text-[var(--accent-purple)]">
                        {d}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Quick stats */}
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.05 }}
              className="grid grid-cols-2 gap-3 sm:grid-cols-3"
            >
              {[
                { icon: BookOpen, label: "Programs", value: "3 active", color: "var(--accent-cyan)" },
                { icon: TrendingUp, label: "Skills mastered", value: `${data.masteredTargets}/${data.totalTargets}`, color: "var(--accent-purple)" },
                { icon: Calendar, label: "Sessions", value: `${data.recentSessions.length} recent`, color: "#34d399" },
              ].map((s) => (
                <div key={s.label} className="glass-card rounded-2xl p-4">
                  <s.icon className="mb-2 h-5 w-5" style={{ color: s.color }} />
                  <div className="text-lg font-bold text-[var(--foreground)]">{s.value}</div>
                  <div className="text-xs text-zinc-500">{s.label}</div>
                </div>
              ))}
            </motion.div>

            {/* Progress chart */}
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="glass-card rounded-2xl p-6"
            >
              <div className="mb-4 flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-[var(--accent-cyan)]" />
                <h3 className="font-semibold text-[var(--foreground)]">Skill progress over time</h3>
              </div>
              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={data.progressData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                  <XAxis dataKey="date" tick={{ fill: "#71717a", fontSize: 11 }} />
                  <YAxis tick={{ fill: "#71717a", fontSize: 11 }} domain={[0, 100]} unit="%" />
                  <Tooltip contentStyle={tooltipStyle} formatter={(v) => [`${v}%`, "% Correct"]} />
                  <Line
                    type="monotone"
                    dataKey="pct"
                    stroke="url(#progressGrad)"
                    strokeWidth={2.5}
                    dot={{ fill: "#22d3ee", r: 3 }}
                    activeDot={{ r: 5 }}
                  />
                  <defs>
                    <linearGradient id="progressGrad" x1="0" y1="0" x2="1" y2="0">
                      <stop offset="0%" stopColor="#22d3ee" />
                      <stop offset="100%" stopColor="#a855f7" />
                    </linearGradient>
                  </defs>
                </LineChart>
              </ResponsiveContainer>
            </motion.div>

            {/* Behavior trends */}
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.15 }}
              className="glass-card rounded-2xl p-6"
            >
              <div className="mb-4 flex items-center gap-2">
                <Activity className="h-5 w-5 text-[var(--accent-pink)]" />
                <h3 className="font-semibold text-[var(--foreground)]">Behavior frequency trend</h3>
              </div>
              <ResponsiveContainer width="100%" height={180}>
                <BarChart data={data.behaviorData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                  <XAxis dataKey="date" tick={{ fill: "#71717a", fontSize: 11 }} />
                  <YAxis tick={{ fill: "#71717a", fontSize: 11 }} />
                  <Tooltip contentStyle={tooltipStyle} />
                  <Bar dataKey="count" fill="rgba(244,63,94,0.7)" radius={[4, 4, 0, 0]} name="Incidents" />
                </BarChart>
              </ResponsiveContainer>
              <p className="mt-2 text-xs text-zinc-500">Lower numbers indicate progress. Speak with your BCBA for detailed analysis.</p>
            </motion.div>

            {/* Recent sessions */}
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="glass-card rounded-2xl p-6"
            >
              <h3 className="mb-4 font-semibold text-[var(--foreground)]">Recent sessions</h3>
              <div className="space-y-3">
                {data.recentSessions.map((s, i) => (
                  <div key={i} className="flex items-start justify-between gap-3 border-b border-[var(--glass-border)] pb-3 last:border-0 last:pb-0">
                    <div>
                      <p className="text-sm font-medium text-[var(--foreground)]">{s.date}</p>
                      {s.note && <p className="mt-0.5 text-sm text-zinc-400">{s.note}</p>}
                    </div>
                    <span className="shrink-0 rounded-full bg-[var(--glass-bg)] px-2.5 py-1 text-xs text-zinc-400">
                      {s.duration} min
                    </span>
                  </div>
                ))}
              </div>
            </motion.div>

            <p className="pb-8 text-center text-xs text-zinc-600">
              This portal displays a summary of your child&apos;s ABA progress. For detailed clinical data or to discuss
              the treatment plan, please contact your BCBA directly.
            </p>
          </>
        )}
      </main>
    </div>
  );
}
