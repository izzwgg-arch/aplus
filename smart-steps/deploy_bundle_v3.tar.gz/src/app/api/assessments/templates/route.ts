import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { prisma } from "@/lib/db";

export async function GET() {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  try {
    const templates = await prisma.assessmentTemplate.findMany({
      where: { isActive: true },
      orderBy: { createdAt: "desc" },
      include: {
        sections: {
          orderBy: { sortOrder: "asc" },
          include: {
            items: { orderBy: { sortOrder: "asc" } },
          },
        },
        _count: {
          select: { clientAssessments: true },
        },
      },
    });

    return NextResponse.json(templates);
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const role = (session.user as { role?: string }).role;
  if (role !== "ADMIN" && role !== "BCBA") {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  try {
    const body = await req.json();
    const { name, description, category, version, scoringMethod, sections } = body;

    if (!name?.trim()) return NextResponse.json({ error: "Name is required" }, { status: 400 });

    const template = await prisma.assessmentTemplate.create({
      data: {
        name: name.trim(),
        description: description?.trim() || null,
        category: category?.trim() || null,
        version: version ?? "1.0",
        scoringMethod: scoringMethod || null,
        createdBy: session.user.id,
        isActive: true,
        sections: sections?.length
          ? {
              create: sections.map((s: { title: string; description?: string; sortOrder?: number; items?: Array<{ text: string; description?: string; responseType: string; options?: unknown; scoreValue?: number; sortOrder?: number; isRequired?: boolean }> }, si: number) => ({
                title: s.title,
                description: s.description || null,
                sortOrder: s.sortOrder ?? si,
                items: s.items?.length
                  ? {
                      create: s.items.map((item, ii) => ({
                        text: item.text,
                        description: item.description || null,
                        responseType: item.responseType,
                        options: item.options ?? null,
                        scoreValue: item.scoreValue ?? null,
                        sortOrder: item.sortOrder ?? ii,
                        isRequired: item.isRequired ?? false,
                      })),
                    }
                  : undefined,
              })),
            }
          : undefined,
      },
      include: {
        sections: {
          include: { items: { orderBy: { sortOrder: "asc" } } },
          orderBy: { sortOrder: "asc" },
        },
      },
    });

    return NextResponse.json(template, { status: 201 });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Failed to create template" }, { status: 500 });
  }
}
