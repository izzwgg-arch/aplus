import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { prisma } from "@/lib/db";
import { auditLog } from "@/lib/auditLogger";

function mockBehaviors(clientId: string) {
  return [
    { id: "b1", sessionId: "s1", type: "ABC", behavior: "Screaming", antecedent: "Demand presented", consequence: "Escape", intensity: "moderate", createdAt: new Date(Date.now() - 86400000).toISOString() },
    { id: "b2", sessionId: "s1", type: "frequency", behavior: "Hand flapping", value: 4, createdAt: new Date(Date.now() - 43200000).toISOString() },
  ];
}

export async function GET(req: Request) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const clientId = searchParams.get("clientId");
  const sessionId = searchParams.get("sessionId");

  try {
    const where = sessionId
      ? { sessionId }
      : clientId
      ? { session: { clientId } }
      : {};

    const behaviors = await prisma.behaviorEvent.findMany({
      where,
      orderBy: { createdAt: "desc" },
      take: 50,
    });

    await auditLog(session.user.id!, "VIEW_CLIENT", "BehaviorEvent", clientId, { query: "GET behaviors" });
    return NextResponse.json(behaviors.length ? behaviors : mockBehaviors(clientId ?? "mock"));
  } catch {
    return NextResponse.json(mockBehaviors(clientId ?? "mock"));
  }
}

export async function POST(req: Request) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  try {
    const body = await req.json() as {
      sessionId: string;
      type: string;
      value?: number;
      antecedent?: string;
      behavior?: string;
      consequence?: string;
      intensity?: string;
    };

    const event = await prisma.behaviorEvent.create({ data: body });
    await auditLog(session.user.id!, "LOG_BEHAVIOR", "BehaviorEvent", event.id);
    return NextResponse.json(event, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}
