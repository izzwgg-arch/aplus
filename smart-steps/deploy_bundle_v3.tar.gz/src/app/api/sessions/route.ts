import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { prisma } from "@/lib/db";

export async function POST(req: Request) {
  const session = await auth();
  const userId = session?.user?.id;
  if (!userId) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  try {
    const body = await req.json();
    const { clientId } = body as { clientId?: string };
    if (!clientId) {
      return NextResponse.json({ error: "clientId required" }, { status: 400 });
    }
    const sessionRecord = await prisma.session.create({
      data: { clientId, userId },
    });
    return NextResponse.json({ id: sessionRecord.id });
  } catch (e) {
    return NextResponse.json(
      { error: "Failed to create session", id: `mock-${Date.now()}` },
      { status: 201 }
    );
  }
}
