import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { prisma } from "@/lib/db";

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ targetId: string }> }
) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { targetId } = await params;

  try {
    const target = await prisma.target.findUnique({
      where: { id: targetId },
      include: {
        trials: {
          take: 100,
          orderBy: { createdAt: "desc" },
          select: { id: true, result: true, promptLevel: true, latencyMs: true, createdAt: true },
        },
      },
    });
    if (!target) return NextResponse.json({ error: "Not found" }, { status: 404 });
    return NextResponse.json(target);
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}

export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ targetId: string }> }
) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const role = (session.user as { role?: string }).role;
  if (role !== "ADMIN" && role !== "BCBA") {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const { targetId } = await params;

  try {
    const body = await req.json();
    const {
      definition,
      targetType,
      phase,
      masteryRule,
      promptHierarchy,
      baseline,
      notes,
      isActive,
      inMaintenance,
      inGeneralization,
    } = body;

    const data: Record<string, unknown> = {};
    if (definition !== undefined) data.definition = definition.trim();
    if (targetType !== undefined) data.targetType = targetType;
    if (phase !== undefined) data.phase = phase;
    if (masteryRule !== undefined) data.masteryRule = masteryRule;
    if (promptHierarchy !== undefined) data.promptHierarchy = promptHierarchy;
    if (baseline !== undefined) data.baseline = baseline?.trim() || null;
    if (notes !== undefined) data.notes = notes?.trim() || null;
    if (isActive !== undefined) data.isActive = Boolean(isActive);
    if (inMaintenance !== undefined) data.inMaintenance = Boolean(inMaintenance);
    if (inGeneralization !== undefined) data.inGeneralization = Boolean(inGeneralization);

    const updated = await prisma.target.update({ where: { id: targetId }, data });
    return NextResponse.json(updated);
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Failed to update target" }, { status: 500 });
  }
}

export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ targetId: string }> }
) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const role = (session.user as { role?: string }).role;
  if (role !== "ADMIN" && role !== "BCBA") {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const { targetId } = await params;

  try {
    await prisma.target.update({
      where: { id: targetId },
      data: { isActive: false },
    });
    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}
