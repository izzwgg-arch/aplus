import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { prisma } from "@/lib/db";

export async function POST(req: Request) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const role = (session.user as { role?: string }).role;
  if (role !== "ADMIN" && role !== "BCBA") {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  try {
    const body = await req.json();
    const {
      definition,
      targetType,
      phase,
      masteryRule,
      promptHierarchy,
      baseline,
      notes,
      programId,
      parentGoalId,
      subGoalId,
    } = body;

    if (!definition?.trim()) return NextResponse.json({ error: "Definition required" }, { status: 400 });
    if (!subGoalId && !parentGoalId && !programId) {
      return NextResponse.json({ error: "Must link target to a program, goal, or sub-goal" }, { status: 400 });
    }

    const target = await prisma.target.create({
      data: {
        definition: definition.trim(),
        targetType: targetType ?? "DISCRETE_TRIAL",
        phase: phase ?? "BASELINE",
        masteryRule: masteryRule ?? null,
        promptHierarchy: Array.isArray(promptHierarchy) ? promptHierarchy : [],
        baseline: baseline?.trim() || null,
        notes: notes?.trim() || null,
        programId: programId || null,
        parentGoalId: parentGoalId || null,
        subGoalId: subGoalId || null,
        isActive: true,
      },
    });

    return NextResponse.json(target, { status: 201 });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Failed to create target" }, { status: 500 });
  }
}
