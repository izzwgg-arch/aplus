"use client";

import Link from "next/link";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Plus, ClipboardList, Edit2, Archive } from "lucide-react";
import { toast } from "sonner";

type Template = {
  id: string;
  name: string;
  description?: string | null;
  category?: string | null;
  version: string;
  scoringMethod?: string | null;
  isActive: boolean;
  createdAt: string;
  sections: { id: string; title: string; items: { id: string }[] }[];
  _count: { clientAssessments: number };
};

function itemCount(t: Template) {
  return t.sections.reduce((acc, s) => acc + s.items.length, 0);
}

export default function AssessmentTemplatesPage() {
  const qc = useQueryClient();

  const { data: templates = [], isLoading, error } = useQuery<Template[]>({
    queryKey: ["assessment-templates"],
    queryFn: async () => {
      const res = await fetch("/smart-steps/api/assessments/templates");
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
  });

  async function archiveTemplate(id: string, name: string) {
    if (!confirm(`Archive "${name}"?`)) return;
    const res = await fetch(`/smart-steps/api/assessments/templates/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isActive: false }),
    });
    if (res.ok) {
      toast.success("Template archived");
      qc.invalidateQueries({ queryKey: ["assessment-templates"] });
    } else {
      toast.error("Failed to archive");
    }
  }

  return (
    <div className="p-6 md:p-8">
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="mb-8 flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[var(--foreground)]">Assessment templates</h1>
          <p className="text-zinc-500 text-sm">Build reusable assessment instruments for your clients</p>
        </div>
        <Link
          href="/assessments/new"
          className="btn-primary tap-target inline-flex items-center gap-2 rounded-xl px-5 py-2.5 text-sm font-semibold"
        >
          <Plus className="h-4 w-4" />
          New template
        </Link>
      </motion.div>

      {error && (
        <div className="mb-4 rounded-2xl border border-[var(--accent-pink)]/30 bg-[var(--accent-pink)]/10 p-4 text-sm text-[var(--accent-pink)]">
          Failed to load templates. Check database connection.
        </div>
      )}

      {isLoading ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {[1, 2, 3].map((i) => <div key={i} className="glass-card skeleton h-40 rounded-2xl" />)}
        </div>
      ) : templates.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-[var(--glass-border)] py-16 text-center">
          <ClipboardList className="h-10 w-10 text-zinc-600 mx-auto mb-3" />
          <p className="text-zinc-400 font-medium mb-1">No assessment templates yet</p>
          <p className="text-zinc-600 text-sm mb-4">Create your first template to start assessing clients</p>
          <Link href="/assessments/new" className="btn-primary inline-flex items-center gap-2 rounded-xl px-5 py-2.5 text-sm font-semibold">
            <Plus className="h-4 w-4" /> Create template
          </Link>
        </div>
      ) : (
        <motion.div
          className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3"
          initial="hidden"
          animate="visible"
          variants={{ visible: { transition: { staggerChildren: 0.05 } }, hidden: {} }}
        >
          {templates.map((t) => (
            <motion.div key={t.id} variants={{ hidden: { opacity: 0, y: 10 }, visible: { opacity: 1, y: 0 } }}>
              <div className="glass-card rounded-2xl p-4 flex flex-col gap-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-[var(--foreground)] truncate">{t.name}</h3>
                    {t.description && <p className="text-xs text-zinc-500 mt-0.5 line-clamp-2">{t.description}</p>}
                  </div>
                  <div className="flex gap-1 shrink-0">
                    <Link
                      href={`/assessments/${t.id}/edit`}
                      className="rounded-lg p-1.5 text-zinc-500 hover:text-[var(--accent-cyan)] transition-colors"
                    >
                      <Edit2 className="h-3.5 w-3.5" />
                    </Link>
                    <button
                      type="button"
                      onClick={() => archiveTemplate(t.id, t.name)}
                      className="rounded-lg p-1.5 text-zinc-600 hover:text-amber-400 transition-colors"
                    >
                      <Archive className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>

                <div className="flex flex-wrap gap-2 text-xs">
                  {t.category && (
                    <span className="rounded-full bg-[var(--accent-purple)]/20 px-2.5 py-0.5 text-[var(--accent-purple)]">
                      {t.category}
                    </span>
                  )}
                  <span className="rounded-full bg-[var(--glass-border)] px-2.5 py-0.5 text-zinc-400">v{t.version}</span>
                  {t.scoringMethod && (
                    <span className="rounded-full bg-[var(--glass-border)] px-2.5 py-0.5 text-zinc-400">{t.scoringMethod}</span>
                  )}
                </div>

                <div className="text-xs text-zinc-500">
                  {t.sections.length} section{t.sections.length !== 1 ? "s" : ""} · {itemCount(t)} item{itemCount(t) !== 1 ? "s" : ""} · used {t._count.clientAssessments}×
                </div>

                <Link
                  href={`/assessments/${t.id}/edit`}
                  className="btn-secondary tap-target rounded-xl py-2 text-sm text-center font-medium"
                >
                  Edit template
                </Link>
              </div>
            </motion.div>
          ))}
        </motion.div>
      )}
    </div>
  );
}
