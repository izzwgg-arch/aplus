"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { ArrowLeft, Plus, ClipboardList, CheckCircle, Clock } from "lucide-react";

type ClientAssessmentSummary = {
  id: string;
  status: string;
  startedAt: string;
  completedAt?: string | null;
  totalScore?: number | null;
  notes?: string | null;
  template: {
    id: string;
    name: string;
    category?: string | null;
    scoringMethod?: string | null;
  };
  completedBy?: { name: string | null } | null;
  _count: { responses: number };
};

export default function ClientAssessmentsPage() {
  const params = useParams();
  const clientId = String(params.clientId ?? "");

  const { data: assessments = [], isLoading, error } = useQuery<ClientAssessmentSummary[]>({
    queryKey: ["client-assessments", clientId],
    queryFn: async () => {
      const res = await fetch(`/smart-steps/api/clients/${clientId}/assessments`);
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
    enabled: !!clientId,
  });

  const completed = assessments.filter((a) => a.status === "COMPLETED");
  const inProgress = assessments.filter((a) => a.status === "IN_PROGRESS");

  return (
    <div className="p-6 md:p-8 max-w-3xl">
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="mb-8 flex items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <Link href={`/clients/${clientId}`} className="tap-target rounded-xl p-2 text-zinc-400 hover:bg-[var(--glass-bg)] hover:text-[var(--foreground)]">
            <ArrowLeft className="h-5 w-5" />
          </Link>
          <div>
            <h1 className="text-2xl font-bold text-[var(--foreground)]">Assessments</h1>
            <p className="text-zinc-500 text-sm">{completed.length} completed · {inProgress.length} in progress</p>
          </div>
        </div>
        <Link
          href={`/clients/${clientId}/assessments/new`}
          className="btn-primary tap-target inline-flex items-center gap-2 rounded-xl px-5 py-2.5 text-sm font-semibold"
        >
          <Plus className="h-4 w-4" />
          New assessment
        </Link>
      </motion.div>

      {error && (
        <div className="mb-4 rounded-2xl border border-[var(--accent-pink)]/30 bg-[var(--accent-pink)]/10 p-4 text-sm text-[var(--accent-pink)]">
          Failed to load assessments.
        </div>
      )}

      {isLoading ? (
        <div className="space-y-3">
          {[1, 2].map((i) => <div key={i} className="glass-card skeleton h-24 rounded-2xl" />)}
        </div>
      ) : assessments.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-[var(--glass-border)] py-16 text-center">
          <ClipboardList className="h-10 w-10 text-zinc-600 mx-auto mb-3" />
          <p className="text-zinc-400 font-medium mb-1">No assessments yet</p>
          <p className="text-zinc-600 text-sm mb-4">Assign an assessment template to start evaluating this client</p>
          <Link href={`/clients/${clientId}/assessments/new`} className="btn-primary inline-flex items-center gap-2 rounded-xl px-5 py-2.5 text-sm font-semibold">
            <Plus className="h-4 w-4" /> Start assessment
          </Link>
        </div>
      ) : (
        <motion.div
          className="space-y-3"
          initial="hidden"
          animate="visible"
          variants={{ visible: { transition: { staggerChildren: 0.05 } }, hidden: {} }}
        >
          {assessments.map((a) => (
            <motion.div key={a.id} variants={{ hidden: { opacity: 0, y: 8 }, visible: { opacity: 1, y: 0 } }}>
              <Link href={`/clients/${clientId}/assessments/${a.id}`}>
                <div className="glass-card rounded-2xl p-4 flex items-center gap-4 hover:shadow-[var(--glow-cyan)] transition-shadow">
                  <div className={`rounded-xl p-3 shrink-0 ${a.status === "COMPLETED" ? "bg-emerald-500/20" : "bg-amber-500/20"}`}>
                    {a.status === "COMPLETED"
                      ? <CheckCircle className="h-5 w-5 text-emerald-400" />
                      : <Clock className="h-5 w-5 text-amber-400" />
                    }
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="font-semibold text-[var(--foreground)] truncate">{a.template.name}</p>
                      <span className={`text-xs px-2 py-0.5 rounded-full shrink-0 ${
                        a.status === "COMPLETED" ? "bg-emerald-500/20 text-emerald-400"
                        : "bg-amber-500/20 text-amber-400"
                      }`}>
                        {a.status === "COMPLETED" ? "Completed" : "In progress"}
                      </span>
                    </div>
                    <p className="text-xs text-zinc-500 mt-0.5">
                      {a.template.category && `${a.template.category} · `}
                      Started {new Date(a.startedAt).toLocaleDateString()}
                      {a.completedAt && ` · Completed ${new Date(a.completedAt).toLocaleDateString()}`}
                    </p>
                    <p className="text-xs text-zinc-600 mt-0.5">
                      {a._count.responses} response{a._count.responses !== 1 ? "s" : ""} saved
                      {a.completedBy?.name && ` · by ${a.completedBy.name}`}
                    </p>
                  </div>
                  {a.totalScore !== null && a.totalScore !== undefined && (
                    <div className="text-right shrink-0">
                      <p className="text-xl font-bold text-[var(--accent-cyan)]">{a.totalScore.toFixed(0)}</p>
                      <p className="text-xs text-zinc-500">total score</p>
                    </div>
                  )}
                </div>
              </Link>
            </motion.div>
          ))}
        </motion.div>
      )}
    </div>
  );
}
