import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { prisma } from "@/lib/db";
import { auditLog } from "@/lib/auditLogger";

type QueueItem = {
  id?: number;
  table: "trials" | "sessions" | "behaviors";
  payload: Record<string, unknown>;
  createdAt: string;
};

const NUMERIC_PROMPT_MAP: Record<string, "FULL_PHYSICAL" | "PARTIAL_PHYSICAL" | "GESTURAL" | "VERBAL" | "MODEL" | "INDEPENDENT"> = {
  "0": "INDEPENDENT",
  "1": "VERBAL",
  "2": "GESTURAL",
  "3": "MODEL",
  "4": "PARTIAL_PHYSICAL",
  "5": "FULL_PHYSICAL",
};

function normalizePromptLevel(value: unknown) {
  if (value == null || value === "") return null;
  const asString = String(value);
  return NUMERIC_PROMPT_MAP[asString] ?? (asString as "FULL_PHYSICAL" | "PARTIAL_PHYSICAL" | "GESTURAL" | "VERBAL" | "MODEL" | "INDEPENDENT");
}

// Offline sync engine: timestamp-based last-write-wins conflict resolution
export async function POST(req: Request) {
  const session = await auth();
  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const body = await req.json();
    const { queue } = body as { queue?: QueueItem[] };
    if (!Array.isArray(queue) || queue.length === 0) {
      return NextResponse.json({ synced: 0, conflicts: [], errors: [] });
    }

    const synced: string[] = [];
    const conflicts: QueueItem[] = [];
    const errors: { item: QueueItem; error: string }[] = [];

    for (const item of queue) {
      try {
        if (item.table === "trials") {
          const p = item.payload;
          // LWW: if a trial with same id exists and is newer, skip
          const existing = p.id
            ? await prisma.trial.findUnique({ where: { id: p.id as string } }).catch(() => null)
            : null;

          if (existing) {
            // Conflict: server record exists — keep server version (LWW)
            conflicts.push(item);
          } else {
            await prisma.trial.create({
              data: {
                sessionId: p.sessionId as string,
                targetId: p.targetId as string,
                result: p.result as "CORRECT" | "INCORRECT" | "PROMPTED" | "NR" | "SKIP",
                promptLevel: normalizePromptLevel(p.promptLevel),
                latencyMs: (p.latencyMs as number | undefined) ?? null,
              },
            });
            synced.push(`trial:${p.targetId}`);
          }
        } else if (item.table === "sessions") {
          const p = item.payload;
          const existing = p.serverId
            ? await prisma.session.findUnique({ where: { id: p.serverId as string } }).catch(() => null)
            : null;
          if (!existing) {
            const created = await prisma.session.create({
              data: {
                clientId: p.clientId as string,
                userId: session.user!.id!,
                startedAt: new Date(p.startedAt as string),
                mode: (p.mode as string | undefined) || "DTT",
              },
            });
            synced.push(`session:${created.id}`);
          }
        } else if (item.table === "behaviors") {
          const p = item.payload;
          await prisma.behaviorEvent.create({
            data: {
              sessionId: p.sessionId as string,
              type: p.type as string,
              value: (p.value as number | undefined) ?? null,
              antecedent: (p.antecedent as string | undefined) ?? null,
              behavior: (p.behavior as string | undefined) ?? null,
              consequence: (p.consequence as string | undefined) ?? null,
              intensity: (p.intensity as string | undefined) ?? null,
            },
          });
          synced.push(`behavior:${p.type}`);
        }
      } catch (e) {
        errors.push({ item, error: String(e) });
      }
    }

    await auditLog(session.user.id!, "LOG_TRIAL", "SyncQueue", null, {
      synced: synced.length,
      conflicts: conflicts.length,
      errors: errors.length,
    });

    return NextResponse.json({ synced: synced.length, syncedIds: synced, conflicts, errors });
  } catch {
    return NextResponse.json({ synced: 0, conflicts: [], errors: [] });
  }
}
