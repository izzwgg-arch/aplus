/**
 * HIPAA Audit Logger — Smart Steps ABA Tracker
 * Writes structured audit entries for all PHI access and mutations.
 */
import { Prisma } from "@prisma/client";
import { prisma } from "./db";

export type AuditAction =
  | "VIEW_CLIENT"
  | "VIEW_REPORT"
  | "CREATE_SESSION"
  | "END_SESSION"
  | "LOG_TRIAL"
  | "LOG_BEHAVIOR"
  | "EXPORT_REPORT"
  | "UPDATE_TARGET"
  | "UPDATE_PROGRAM"
  | "UPDATE_BEHAVIOR_PLAN"
  | "DELETE_RECORD"
  | "SSO_LOGIN"
  | "MANUAL_LOGIN"
  | "LOGOUT";

export async function auditLog(
  userId: string,
  action: AuditAction,
  entityType: string,
  entityId?: string | null,
  details?: Record<string, unknown>
): Promise<void> {
  try {
    await prisma.auditEntry.create({
      data: {
        userId,
        action,
        entityType,
        entityId: entityId ?? null,
        details: details ? (details as Prisma.InputJsonValue) : Prisma.JsonNull,
      },
    });
  } catch {
    // Never let audit logging crash the application
    console.error("[AuditLogger] Failed to write audit entry", { userId, action, entityType, entityId });
  }
}

/** Convenience: log a trial batch */
export async function auditTrials(userId: string, sessionId: string, count: number) {
  return auditLog(userId, "LOG_TRIAL", "Session", sessionId, { trialCount: count });
}

/** Convenience: log a report export */
export async function auditExport(userId: string, format: string, clientId?: string | null) {
  return auditLog(userId, "EXPORT_REPORT", "Report", clientId, { format });
}
